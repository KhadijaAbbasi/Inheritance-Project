import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:practice/authentication_repository.dart';
import 'package:practice/constant.dart';
import 'home.dart';
import 'package:lottie/lottie.dart';
import 'package:get/get.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase and set up the AuthenticationRepository
  Firebase.initializeApp().then((value) => Get.put(AuthenticationRepository()));

  // Run the app
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          color: Colors.orange.shade300,
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const Splashscreen(), // Show Splashscreen as the initial screen
    );
  }
}

class Splashscreen extends StatefulWidget {
  const Splashscreen({key}) : super(key: key);

  @override
  State<Splashscreen> createState() => SplashscreenState();
}

class SplashscreenState extends State<Splashscreen> with TickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    // Initialize the AnimationController for Lottie animation
    _controller = AnimationController(vsync: this);

    // Add a status listener to the AnimationController
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        // When animation is completed, navigate to the Home screen
        Get.off(() => const Home());
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      body: Center(
        child: Lottie.asset(
          'assets/Inheritance_Rights.json',
          height: 800,
          width: 800,
          fit: BoxFit.fill,
          repeat: false,
          controller: _controller,
          onLoaded: (composition) {
            // Configure the AnimationController with the duration of the
            // Lottie file and start the animation.
            _controller.duration = composition.duration;
            _controller.forward(); // Start the animation
          },
        ),
      ),
    );
  }
}
