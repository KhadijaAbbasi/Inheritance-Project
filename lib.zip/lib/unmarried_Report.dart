import 'dart:io';
import 'package:flutter/material.dart';
import 'button.dart';
import 'constant.dart';
import 'home.dart';
import 'primary_heirs.dart';
import 'deceased_data.dart';
import 'primary_heirs_data.dart';
import 'reuseable_Container.dart';
import 'package:getwidget/getwidget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'user_login.dart';
import 'admin_login.dart';
import 'Rules.dart';
import 'secondary_data.dart';

class UnmarriedHeirsReport extends StatefulWidget {
  const UnmarriedHeirsReport({Key? key}) : super(key: key);

  @override
  State<UnmarriedHeirsReport> createState() => _UnmarriedHeirsReportState();
}

class _UnmarriedHeirsReportState extends State<UnmarriedHeirsReport> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => PrimaryHeirs()),
            );
          },
          icon: Icon(
            Icons.arrow_back,
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(left: 60.0),
          child: Text(
            'WarisApp',
            style: kAppBarTextStyle,
          ),
        ),
        actions: [
          PopupMenuButton(
            color: colormustard,
            itemBuilder: (context) => [
              PopupMenuItem<int>(
                padding: EdgeInsets.all(15.0),
                child: Column(
                  children: [
                    GestureDetector(
                      child: Row(
                        children: [
                          Icon(
                            Icons.home,
                            color: colorblack,
                            size: 20.0,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text('Home'),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Home()),
                      ),
                    ),
                    SizedBox(height: 20),
                    GestureDetector(
                      child: Row(
                        children: [
                          SizedBox(
                            height: 20,
                            width: 20,
                            child: Image.asset("images/complain.png"),
                          ),
                          SizedBox(width: 10),
                          Text('Complaint'),
                        ],
                      ),
                      onTap: () => selectperson(context),
                    ),
                    SizedBox(height: 20),
                    GestureDetector(
                      child: Row(
                        children: [
                          Icon(
                            Icons.exit_to_app,
                            color: colorblack,
                            size: 20.0,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text('Exit'),
                        ],
                      ),
                      onTap: () => exit(0), // call this to exit app
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
        elevation: 0.0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 1,
            child: Container(
              padding: EdgeInsets.all(15.0),
              child: Text(
                'Shares of Heirs according to Islamic Shariah',
                style: kHeadingTextStyle.copyWith(height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: SingleChildScrollView(
              child: ReuseableContainer(
                colour: Colors.lime.shade50,
                childCard: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Father Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      firstHeirs.fatherName! +
                          " will get Rs." +
                          firstHeirs.fatherShares.toString() +
                          " from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 15.0),
                    Text(
                      "Mother Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      firstHeirs.motherName! +
                          " will get Rs." +
                          firstHeirs.motherShares.toString() +
                          " from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    SizedBox(height: 15.0),
                    Text(
                      "True GrandFather Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      SecondHeirs.grandFatherName! +
                          " will get Rs." +
                          SecondHeirs.grandFatherShares.toString() +
                          " from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    SizedBox(height: 15.0),
                    Text(
                      "True GrandMother Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      SecondHeirs.grandMotherName! +
                          " will get Rs." +
                          SecondHeirs.grandMotherShares.toString() +
                          " from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    SizedBox(height: 15.0),
                    Text(
                      "Maternal GrandFather Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      SecondHeirs.M_grandMothername! +
                          " will get Rs." +
                          SecondHeirs.M_grandMotherShares.toString() +
                          " from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    SizedBox(height: 15.0),
                    Text(
                      "Real Sister Shares:",
                      style: kHeadingTextStyle,
                    ),
                    SizedBox(height: 10.0),
                    Text(
                      "Sisters will get Rs." +
                          SecondHeirs.SisterShares.toString() +
                          " each from Total Amount which is Rs." +
                          PropertyDetails.Total.toString(),
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
         Padding(
           padding: const EdgeInsets.only(bottom: 30.0, right: 20.0),
           child: gfButton(
             ButtonTitle: 'View Rules',
             onPressed: () {
               Navigator.push(
                 context,
                 MaterialPageRoute(
                     builder: (context) => ViewRules()),
               );
             },
           ),
         ),
        ],
      ),
    );
  }

  void selectperson(BuildContext context) {
    var alertDialog = AlertDialog(
      backgroundColor: colormustard,
      title: Text('Are You?',
          textAlign: TextAlign.center, style: kInheritanceTextStyle),
      content: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        GFButton(
            icon: Icon(
              FontAwesomeIcons.userCircle,
              size: 20,
            ),
            text: "Admin",
            textStyle: kInheritanceTextStyle,
            shape: GFButtonShape.standard,
            color: colorbluegreyshade,
            size: 40,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminLogin()),
              );
            }),
        SizedBox(width: 10),
        GFButton(
            icon: Icon(
              FontAwesomeIcons.users,
              size: 20,
            ),
            text: " User ",
            textStyle: kInheritanceTextStyle,
            shape: GFButtonShape.standard,
            color: colorbluegreyshade,
            size: 40,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserLogin()),
              );
            }),
      ]),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }
}
