import 'package:flutter/material.dart';
import 'button.dart';
import 'constant.dart';
import 'deceased_data.dart';
import 'package:flutter/cupertino.dart';
import 'primary_heirs_report.dart';
import 'primary_heirs_data.dart';
import 'calculation.dart';

// List of options for father's and mother's status
const List<String> fatherStatus = <String>['ALive', 'Dead'];
const List<String> motherStatus = <String>['ALive', 'Dead'];

// Instance of SunniSharesCalculation for calculating Sunni shares
SunniSharesCalculation calculateSunniShares = SunniSharesCalculation();

class PrimaryHeirs extends StatefulWidget {
  const PrimaryHeirs({Key? key}) : super(key: key);

  @override
  State<PrimaryHeirs> createState() => _PrimaryHeirsState();
}

class _PrimaryHeirsState extends State<PrimaryHeirs> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Change your color here
          size: 30,
        ),
        title: const Padding(
            padding: EdgeInsets.only(left: 60.0),
            child: Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )),
        elevation: 0.0,
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: kBackgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0, top: 20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text("Primary heirs",
                      style: kHeadingTextStyle.copyWith(fontSize: 30)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            firstHeirs.fatherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter deceased's Father name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Required';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: firstHeirs.fatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                firstHeirs.fatherStatus = value!;
                              });
                              },
                            items: fatherStatus
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            firstHeirs.motherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter deceased's Mother name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Required';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: firstHeirs.motherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                firstHeirs. motherStatus = value!;
                              });
                            },
                            items: motherStatus
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Visibility(
                      visible: DeceasedDetails.showMaritalStatus,
                      child:Column(
                          children:[
                            TextFormField(
                              onChanged: (value) {
                                firstHeirs.no_of_wife = int.parse(value);
                              },
                              decoration: kInputDecoration.copyWith(
                                  hintText: "Enter number of Spouse"),
                              keyboardType: TextInputType.number,
                              maxLength: 1,
                              validator: ((value) {
                                if (value!.isEmpty) {
                                  return 'Required';
                                } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                                  return 'Text is not allowed';
                                }
                              }),
                            ),
                            const SizedBox(height: 10),
                            TextFormField(
                              onChanged: (value) {
                                firstHeirs.no_of_son = int.parse(value);
                              },
                              decoration: kInputDecoration.copyWith(
                                  hintText: "Enter number of Sons"),
                              keyboardType: TextInputType.number,
                              maxLength: 2,
                              validator: ((value) {
                                if (value!.isEmpty) {
                                  return 'Required';
                                } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                                  return 'Text is not allowed';
                                }
                              }),
                            ),
                            const SizedBox(height: 10),
                            TextFormField(
                              onChanged: (value) {
                                firstHeirs.no_of_Daughter = int.parse(value);
                              },
                              decoration: kInputDecoration.copyWith(
                                  hintText: "Enter number of daughter"),
                              keyboardType: TextInputType.number,
                              maxLength: 2,
                              validator: ((value) {
                                if (value!.isEmpty)
                                  return 'Required';
                                else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                                  return 'Text is not allowed';
                                }
                              }),
                            ),
                            const SizedBox(height: 10),
                          ])
                  ),
                  TextFormField(
                    onChanged: (value) {
                      firstHeirs.no_of_sister = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter number of sisters"),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return 'Required';
                      } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Text is not allowed';
                      }
                    }),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    onChanged: (value) {
                      firstHeirs.no_of_Brother = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter number of brothers"),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return 'Required';
                      } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Text is not allowed';
                      }
                    }),
                  ),
                  const SizedBox(height: 10),

                  gfButton(
                    ButtonTitle: 'Calculate',
                    onPressed: () {
                      bool isValid = _formKey.currentState!.validate();
                      if (isValid) {
                        if (firstHeirs.fatherStatus == null ||
                            firstHeirs.motherStatus == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Please Select Status',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: colorblack,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              backgroundColor: Color(0xFFe1c7a0),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        } else {
                          if (DeceasedDetails.fiqh == 'Sunni') {
                            calculateSunniShares.PrimaryHeirs_calculation();
                          }
                          loading(context);
                        }
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void loading(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 3), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PrimaryHeirsReport()),
          );
        });
        return const AlertDialog(
          backgroundColor: colormustard,
          title: Text('Please wait a movement'),
          content: CupertinoActivityIndicator(
              radius: 20.0),
        );
      },
    );
  }
}
