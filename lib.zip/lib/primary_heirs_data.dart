

class firstHeirs {
  static String? motherName,fatherName;
  static int no_of_son=0,no_of_Daughter=0,no_of_wife=0,no_of_sister=0,no_of_Brother=0;
  static int SpouseShares=0,daughterShares=0,sonShares=0,fatherShares=0,motherShares=0;
  static String? motherStatus;
  static String? fatherStatus;
  static bool ShowNextButton = true;
  static bool ShowReportButton = false;
}