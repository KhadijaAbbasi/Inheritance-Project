import 'package:flutter/material.dart';
import 'constant.dart';
import 'package:getwidget/getwidget.dart';
import 'home.dart';

class About extends StatefulWidget {
  const About({Key? key}) : super(key: key);

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard, // Setting background color
      resizeToAvoidBottomInset: false, // Avoiding resizing when keyboard appears
      extendBodyBehindAppBar: false,
      appBar: GFAppBar(
        backgroundColor: Colors.orange.shade300,
        iconTheme: const IconThemeData(
          color: colorblack, // Changing icon color
          size: 30,
        ),
        title: const Padding(
          padding: EdgeInsets.only(left: 60.0),
          child: Text(
            "WarisApp", // AppBar title
            style: kAppBarTextStyle,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()), // Navigating to Home page
              );
            },
            icon: const Icon(
              Icons.home, // Home icon
            ),
          )
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 10.0),
          const Center(
            child: Text(
              '~ About WarisApp ~', // Centered title
              style: kInheritanceTextStyle,
            ),
          ),
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                color: coloryellowish, // Background color for the container
                borderRadius: BorderRadius.circular(10.0), // Rounded corners
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'WarisApp is an Android Based Application, a platform specifically designed and developed:',
                      style: kAhadithHeadingTextStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      '\n* To compute the inheritance shares of the heirs (in amount) accurately, based on Islamic principles'
                          '\n* To aid the users of Pakistan in filing a complaint to the Regulatory Bodies (Admin), when they remain deprived off their inheritance rights',
                      style: kAhadithHeadingTextStyle,
                    ),

                    Text(
                      '\nSoftware tools used in the development of WarisApp are:',
                      style: kAhadithHeadingTextStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      '\n* Flutter Framework'
                          '\n* SDK (Software Development Kit)'
                          '\n* Dart Programming Language',
                      style: kAhadithHeadingTextStyle,
                    ),

                    Text(
                      '\nDevelopers of the WarisApp:',
                      style: kAhadithHeadingTextStyle.copyWith(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.left,
                    ),
                    const Text(
                      '\n* IZZA YAQOOB'
                          '\n* SOMA KARIM'
                          '\n* KHADIJA AMJAD ABBASI'
                          '\n(Students of Software Engineering Department, Fatima Jinnah Women University)',
                      style: kAhadithHeadingTextStyle,
                    ),

                    Text(
                      '\nSupervisor:',
                      style: kAhadithHeadingTextStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      '\n* Ms. Mukhtiar Bano (Assistant Professor Software Engineering Department, Fatima Jinnah Women University)'
                          '\n* Dr. Mehreen Sirshar (Head of Software Engineering Department, Fatima Jinnah Women University)',
                      style: kAhadithHeadingTextStyle,
                    ),

                    Text(
                      '\nConsultants:',
                      style: kAhadithHeadingTextStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      '\n* Dr. Aftab Alam (Professor Islamic Studies Department, Fatima Jinnah Women University)',
                      style: kAhadithHeadingTextStyle,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
