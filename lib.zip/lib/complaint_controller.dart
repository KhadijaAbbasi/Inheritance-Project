import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:practice/user_section.dart';
import 'complaint_model.dart';
import 'constant.dart';

class ComplaintController extends GetxController {

  static ComplaintController get instance => Get.find();

  final DeceasedName = TextEditingController();
  final DeceasedCNIC = TextEditingController();
  final ComplainerName = TextEditingController();
  final ComplainerRelation = TextEditingController();
  final ComplainerPhNo = TextEditingController();
  final Description = TextEditingController();

  final _db = FirebaseFirestore.instance;

  //Register User Complaints
  Future<bool> RegisterComplaint (ComplaintModel complaint) async {
   try
   { await _db.collection("Complaints")
        .add(complaint.toJson())
        .whenComplete(() =>
    { Get.snackbar("Success", 'Your Complaint has been registered',
        backgroundColor: colormustard),
      Get.offAll(() => userPage())
    });
     return true;
  } catch (error) {
     Get.snackbar("Error", error.toString(),
             backgroundColor: colormustard);
     return false; // Return false indicating failure
   }
  }

  //Resolved complaints
  Future<bool> moveComplaintToResolved(String documentId, Map<String, dynamic> complaintData) async {
    try {
      await FirebaseFirestore.instance
          .collection('Resolved Complaints')
          .doc(documentId)
          .set(complaintData);
      return true; // Return true indicating success
    }
    catch (error) {
      Get.snackbar("Error", error.toString(),
            backgroundColor: colormustard);
      return false; // Return false indicating failure
    }
  }

  // Method to get the number of pending complaints
  Future<int> getPendingComplaints() async {
    final snapshot = await FirebaseFirestore.instance
        .collection("Complaints")
        .get();
    return snapshot.size;
  }

  // Method to get the number of resolved complaints
  Future<int> getTotalResolvedComplaints() async {
    final snapshot = await FirebaseFirestore.instance
        .collection("Resolved Complaints")
        .get();
    return snapshot.size;
  }

  // Method to get the number of complaints in a specific city
  Future<int> getComplaintsByCity(String city) async {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('Complaints')
          .where('ComplaintCity', isEqualTo: city)
          .get();
      final citySnapshot = await FirebaseFirestore.instance
          .collection('Resolved Complaints')
          .where('ComplaintCity', isEqualTo: city)
          .get();
      return querySnapshot.size+citySnapshot.size;
  }

}


