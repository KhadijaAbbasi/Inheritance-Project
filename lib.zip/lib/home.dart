import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/deceased_data.dart';
import 'NADRA_Entry.dart';
import 'manual_entry.dart';
import 'services.dart';
import 'side_bar.dart';
import 'package:practice/constant.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: const NavBar(),
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Change your color here
          size: 30,
        ),
        title: const Center(
          child: Text(
            'Inheritance Rights',
            style: kAppBarTextStyle,
          ),
        ),
        elevation: 0.0,
      ),
      body: Container(
        height: 1000,
        decoration: kBackgroundDecoration,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(30, 150, 30, 20),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              children: <Widget>[
                const CircleAvatar(
                  radius: 105,
                  backgroundImage: AssetImage('images/logo_BgRemove.png'),
                  backgroundColor: colormustard,
                ),
                const SizedBox(
                  height: 10,
                ),
                GFAccordion(
                  titlePadding: const EdgeInsets.fromLTRB(40, 10, 20, 10),
                  contentPadding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                  collapsedTitleBackgroundColor: Colors.amber.shade300,
                  expandedTitleBackgroundColor: Colors.orangeAccent,
                  collapsedIcon: const Icon(
                    Icons.keyboard_arrow_down,
                    color: colorblack,
                  ),
                  contentBackgroundColor: Colors.transparent,
                  titleBorderRadius: const BorderRadius.all(Radius.circular(20)),
                  title: 'Islamic Inheritance',
                  textStyle: const TextStyle(
                    color: colorblack,
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                  contentChild: Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Column(
                      children: [
                        GFAccordion(
                          titlePadding: const EdgeInsets.fromLTRB(30, 10, 30, 10),
                          contentPadding: const EdgeInsets.fromLTRB(30, 15, 30, 10),
                          collapsedTitleBackgroundColor: colorgrey,
                          expandedTitleBackgroundColor: Colors.grey.shade700,
                          titleBorderRadius:
                          const BorderRadius.all(Radius.circular(20)),
                          title: 'Sunni Fiqh',
                          textStyle: const TextStyle(
                            color: colorwhite,
                            fontSize: 20,
                          ),
                          collapsedIcon: const Icon(
                            Icons.keyboard_arrow_down,
                            color: colorwhite,
                          ),
                          contentBackgroundColor: Colors.transparent,
                          contentChild: Column(
                            children: [
                              GFButton(
                                onPressed: () {
                                  DeceasedDetails.fiqh = 'Sunni';
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                      const DeceasedEntry(),
                                    ),
                                  );
                                },
                                text: "Manual",
                                textStyle: const TextStyle(fontSize: 25),
                                shape: GFButtonShape.pills,
                                size: 40,
                                blockButton: true,
                                color: colorgrey,
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              GFButton(
                                onPressed: () {
                                  DeceasedDetails.fiqh = 'Sunni';
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const DeceasedCNIC(),
                                    ),
                                  );
                                },
                                text: "NADRA",
                                textStyle: const TextStyle(fontSize: 25),
                                shape: GFButtonShape.pills,
                                size: 40,
                                blockButton: true,
                                color: colorgrey,
                              ),
                            ],
                          ),
                        ),
                        GFAccordion(
                          titlePadding: const EdgeInsets.fromLTRB(30, 10, 30, 10),
                          contentPadding: const EdgeInsets.fromLTRB(30, 15, 30, 0),
                          collapsedTitleBackgroundColor: colorgrey,
                          expandedTitleBackgroundColor: Colors.grey.shade700,
                          titleBorderRadius:
                          const BorderRadius.all(Radius.circular(20)),
                          title: 'Jaffriah Fiqh',
                          textStyle: const TextStyle(
                            color: colorwhite,
                            fontSize: 20,
                          ),
                          collapsedIcon: const Icon(
                            Icons.keyboard_arrow_down,
                            color: colorwhite,
                          ),
                          contentBackgroundColor: Colors.transparent,
                          contentChild: Column(
                            children: [
                              GFButton(
                                onPressed: () {
                                  DeceasedDetails.fiqh = 'Jaffriah';
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                      const DeceasedEntry(),
                                    ),
                                  );
                                },
                                text: "Manual",
                                textStyle: const TextStyle(fontSize: 25),
                                shape: GFButtonShape.pills,
                                size: 40,
                                blockButton: true,
                                color: colorgrey,
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              GFButton(
                                onPressed: () {
                                  DeceasedDetails.fiqh = 'Jaffriah';
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const DeceasedCNIC(),
                                    ),
                                  );
                                },
                                text: "NADRA",
                                textStyle: const TextStyle(fontSize: 25),
                                shape: GFButtonShape.pills,
                                size: 40,
                                blockButton: true,
                                color: colorgrey,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: Column(
                    children: [
                      GFButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Services(),
                            ),
                          );
                        },
                        text: "Christianity Inheritance",
                        textStyle: const TextStyle(
                          fontSize: 20,
                          color: colorblack,
                          fontWeight: FontWeight.w500,
                        ),
                        shape: GFButtonShape.pills,
                        size: 45,
                        blockButton: true,
                        color: Colors.orange.shade200,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      GFButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Services(),
                            ),
                          );
                        },
                        text: "Hinduism Inheritance",
                        textStyle: const TextStyle(
                          fontSize: 20,
                          color: colorblack,
                          fontWeight: FontWeight.w500,
                        ),
                        shape: GFButtonShape.pills,
                        size: 45,
                        blockButton: true,
                        color: Colors.amberAccent.shade100,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      GFButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Services(),
                            ),
                          );
                        },
                        text: "Buddhism Inheritance",
                        textStyle: const TextStyle(
                          fontSize: 20,
                          color: colorblack,
                          fontWeight: FontWeight.w500,
                        ),
                        shape: GFButtonShape.pills,
                        size: 45,
                        blockButton: true,
                        color: Colors.orange.shade300,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
