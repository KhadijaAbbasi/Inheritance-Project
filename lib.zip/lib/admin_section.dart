import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/complaints_data.dart';
import 'authentication_repository.dart';
import 'complaint_controller.dart';
import 'constant.dart';
import 'package:get/get.dart';

import 'home.dart';

class AdminPage extends StatefulWidget {
  final String adminCity; // Parameter to hold the admin's city

  const AdminPage({Key? key, required this.adminCity}) : super(key: key);

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final controller = Get.put(ComplaintController());

  int totalRegisteredComplaints = 0;
  int pendingComplaints = 0;
  int totalResolvedComplaints = 0;
  int complaintsInIslamabad = 0;
  int complaintsInRawalpindi = 0;

  @override
  void initState() {
    super.initState();
    loadComplaintCounts();
  }

  Future<void> loadComplaintCounts() async {
    pendingComplaints = await controller.getPendingComplaints();
    totalResolvedComplaints = await controller.getTotalResolvedComplaints();
    complaintsInIslamabad = await controller.getComplaintsByCity('Islamabad');
    complaintsInRawalpindi = await controller.getComplaintsByCity('Rawalpindi');
    totalRegisteredComplaints = pendingComplaints + totalResolvedComplaints;
    setState(() {});
  }

  // Function to handle complaint moved event
  void onComplaintMoved() {
    loadComplaintCounts(); // Reload complaint counts
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: GFAppBar(
        backgroundColor: Colors.orange.shade300,
        iconTheme: const IconThemeData(
          color: colorblack,
          size: 30,
        ),
        actions: [
          IconButton(
            onPressed: () {
              AuthenticationRepository.instance.adminlogout();
              Get.offAll(() => const Home());
            },
            icon: const Icon(
              Icons.logout,
            ),
          )
        ],
        title: Center(
          child: Text(
            "Admin Panel", // AppBar title
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
      ),
      body: Container(
        decoration: kBackgroundDecoration, // Background decoration
        child: Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20.0),
          child: Column(
            children: <Widget>[
              //Logo
              const CircleAvatar(
                radius: 100,
                backgroundImage: AssetImage('images/logo_BgRemove.png'),
                backgroundColor: colormustard,
              ),
              Container(
                height: 100,
                width: 400,
                decoration: BoxDecoration(
                  color: Colors.orange.shade300,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: Padding(
                  padding: EdgeInsets.all(30.0),
                  child: Text(
                    "Total number of complaints registered: $totalRegisteredComplaints",
                    style: TextStyle(fontSize: 17),
                  ),
                ),
              ),
              SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    child:  Container(
                      height: 130,
                      decoration: BoxDecoration(
                        color: Colors.orange.shade300,
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(15.0),
                        child: Text(
                          "Number of pending complaints: $pendingComplaints",
                          style: TextStyle(fontSize: 17),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child:   Container(
                      height: 130,
                      decoration: BoxDecoration(
                        color: Colors.orange.shade300,
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(15.0),
                        child: Text(
                          "Number of resolved complaints: $totalResolvedComplaints",
                          style: TextStyle(fontSize: 17),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    child:  Container(
                      height: 130,
                      decoration: BoxDecoration(
                        color: Colors.orange.shade300,
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      child:  Padding(
                        padding: EdgeInsets.all(15.0),
                        child: Text(
                          "Number of complaints registered in Islamabad: $complaintsInIslamabad",
                          style: TextStyle(fontSize: 17),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Container(
                      height: 130,
                      decoration: BoxDecoration(
                        color: Colors.orange.shade300,
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      child:  Padding(
                        padding: EdgeInsets.all(15.0),
                        child: Text(
                          "Number of complaints registered in Rawalpindi: $complaintsInRawalpindi",
                          style: TextStyle(fontSize: 17),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Button to navigate to complaints data page
              GFButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ComplaintsData(
                        adminCity: widget.adminCity,
                        onComplaintMoved: onComplaintMoved, // Pass the callback
                      ),
                    ),
                  );
                },
                text: "View Users Complaints", // Button text
                textStyle: const TextStyle(
                    fontSize: 20,
                    color: colorblack,
                    fontWeight: FontWeight.w800),
                shape: GFButtonShape.standard,
                size: 60,
                blockButton: true,
                color: Colors.orange.shade300,
                boxShadow: BoxShadow(
                  color: Colors.grey.withOpacity(0.6),
                  spreadRadius: 5,
                  blurRadius: 5,
                  offset: Offset(0, 3), // Shadow offset
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
