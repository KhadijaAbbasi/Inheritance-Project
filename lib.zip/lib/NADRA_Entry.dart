import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/constant.dart';
import 'package:practice/services.dart';
import 'button.dart';

class DeceasedCNIC extends StatefulWidget {
  const DeceasedCNIC({Key? key}) : super(key: key);

  @override
  State<DeceasedCNIC> createState() => _DeceasedCNICState();
}

class _DeceasedCNICState extends State<DeceasedCNIC> {
  final _formKey = GlobalKey<FormState>();
  int? NIC;

  // Function to handle form validation and navigation
  _validation() {
    if (_formKey.currentState!.validate()) {
      // Navigate to Services screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Services()),
      );

      // Reset the form
      _formKey.currentState!.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: GFAppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        iconTheme: const IconThemeData(
          color: Colors.white, //change your color here
          size: 30,
        ),
        title: const Padding(
          padding: EdgeInsets.only(left: 60.0),
          child: Text(
            "WarisApp",
            style: kAppBarTextStyleOwner,
          ),
        ),
      ),
      body: Container(
        decoration: kBackgroundDecoration,
        child: Column(
          children: [
            // Display Image Overlay
            GFImageOverlay(
              height: 250,
              image: const AssetImage('images/scenery.png'),
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.4),
                BlendMode.darken,
              ),
            ),
            // Display Text and Divider
            const Text(
              "Inheritance Calculation According To Islamic Shariah",
              textAlign: TextAlign.center,
              style: kInheritanceTextStyle,
            ),
            divider,
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 100.0, 20.0, 20.0),
              child: Form(
                key: _formKey,
                child: TextFormField(
                  onChanged: (value) {
                    NIC = int.parse(value);
                  },
                  decoration: kInputDecoration.copyWith(
                    hintText: "Enter Deceased's CNIC - without dashes",
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 2,
                        color: colorbluegrey,
                      ),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  keyboardType: TextInputType.number,
                  maxLength: 13,
                  validator: (value) {
                    // Validation logic for CNIC input
                    if (value!.isEmpty) {
                      return "Please enter deceased CNIC ";
                    } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                      return 'Text is not allowed in this field';
                    }else if (value.length < 13)
                    {
                      return ' CNIC should be of 13 digit';
                    }
                  },
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 30.0, left: 30.0),
              child: gfButton(
                ButtonTitle: 'Next',
                onPressed: () {
                  _validation();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
