
class UserModel{
  final String? FullName;
  final String? Email;
  final String? Gender;
  final String? PhoneNumber;
  final String? Password;

const UserModel({required this.FullName,
  required this.Email,
  required this.Gender,
  required this.PhoneNumber,
  required this.Password
});

toJson()
{
  return {
    "FullName": FullName,
    "userEmail": Email,
    "Gender": Gender,
    "PhoneNumber": PhoneNumber,
    "Password":  Password
  };
}

}