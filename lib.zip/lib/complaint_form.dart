import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/signup_controller.dart';
import 'authentication_repository.dart';
import 'complaint_controller.dart';
import 'complaint_model.dart';
import 'constant.dart';
import 'button.dart';
import 'package:get/get.dart';


const List<String> city = <String>['Islamabad', 'Rawalpindi'];

class Complaint extends StatefulWidget {
  const Complaint({Key? key}) : super(key: key);

  @override
  State<Complaint> createState() => _ComplaintState();
}

class _ComplaintState extends State<Complaint> {
  @override

  final _formKey = GlobalKey<FormState>();
  final controller= Get.put(ComplaintController());
  String City="";

  void _validate()
  {
    bool isValid = _formKey.currentState!.validate();
    if (isValid) { //form is valid
      final complaint = ComplaintModel(
        userEmail: AuthenticationRepository.instance.userEmail,
        DeceasedName: controller.DeceasedName.text.trim(),
        DeceasedCNIC: controller.DeceasedCNIC.text.trim(),
        ComplainerName: controller.ComplainerName.text.trim(),
        ComplainerRelation: controller.ComplainerRelation.text.trim(),
        ComplainerPhNo: controller.ComplainerPhNo.text.trim(),
        ComplaintCity: City,
        Description: controller.Description.text.trim(),
      );
      bool temp = SignUpController.instance.RegisterComplaints(complaint) as bool;
      if (temp == true) {
        _formKey.currentState!.reset();
      }
    }
  }


  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: GFAppBar(
       backgroundColor: Colors.orange.shade300,
       iconTheme: const IconThemeData(
         color: colorblack, //change your color here
         size: 30,
       ),
       title: Center(
         child: Text("Complaint Section",
           style:kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
         ),
       ),
     ),
     body:  Container(
       height: 800,
       padding: const EdgeInsets.only(left: 30, right: 30,top: 50),
       decoration: const BoxDecoration(
         image: DecorationImage(
           image: AssetImage("images/background.png"),
           fit: BoxFit.cover,
         ),
       ),
       child: SingleChildScrollView(
         physics: const BouncingScrollPhysics(),
         child: Form(
           key: _formKey,
           child: Column(
             mainAxisAlignment: MainAxisAlignment.center,
             children: <Widget>[
               TextFormField(
                  controller: controller.DeceasedName,
                 decoration: kInputDecoration.copyWith(
                     hintText: 'Enter deceased\'s name'),
                 cursorColor: colorbluegrey,
                 maxLength: 25,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter Deceased Name';
                   }
                 },
               ),

               const SizedBox(
                 height: 20,
               ),

               TextFormField(
                 controller: controller.DeceasedCNIC,
                   decoration:  kInputDecoration.copyWith(
                       hintText: 'Enter deceased CNIC without dashes'),
                  keyboardType: TextInputType.number,
                 cursorColor: colorbluegrey,
                 maxLength: 13,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter Deceased CNIC';
                   }
                   if(!RegExp(r'^[0-9]+$').hasMatch(value)) {
                     return 'Text is not allowed in this field';
                   }
                   },
                   ),

               const SizedBox(
                 height: 20,
               ),

               TextFormField(
                 controller: controller.ComplainerName,
                 decoration: kInputDecoration.copyWith(
                     hintText: 'Enter your name'),
                 cursorColor: colorbluegrey,
                 maxLength: 25,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter your Name';
                   }
                   if(!RegExp(r'^[a-z A-Z]+$').hasMatch(value)) {
                     return 'Numbers are not allowed in this field';
                   }
                 },
               ),

               const SizedBox(
                 height: 20,
               ),

               TextFormField(
                 controller: controller.ComplainerRelation,
                 decoration: kInputDecoration.copyWith(
                     hintText: 'Enter your relation with deceased'),
                 cursorColor: colorbluegrey,
                 maxLength: 25,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter Phone Number';
                   }
                   if(!RegExp(r'^[a-z A-Z]+$').hasMatch(value)) {
                     return 'Numbers are not allowed in this field';
                   }
                 },
               ),

               const SizedBox(
                 height: 20,
               ),

               TextFormField(
                 controller: controller.ComplainerPhNo,
                 decoration:  kInputDecoration.copyWith(
                     hintText: 'Enter your Phone Number'),
                 keyboardType: TextInputType.number,
                 cursorColor: colorbluegrey,
                 maxLength: 11,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter your Phone Number';
                   }
                   if(!RegExp(r'^[0-9]+$').hasMatch(value)) {
                     return 'Text is not allowed in this field';
                   }
                 },
               ),

               const SizedBox(
                 height: 20,
               ),

               DropDownDecorationBoxDeceased(
                 child: DropDown(),
               ),

               const SizedBox(
                 height: 20,
               ),

               TextFormField(
                 controller:controller.Description,
                 decoration:  kInputDecoration.copyWith(
                     hintText: 'Description of problem'),
                 minLines: 8, // any number you need (It works as the rows for the textarea)
                 maxLines: null,
                 cursorColor: colorbluegrey,
                 keyboardType: TextInputType.multiline,
                 validator: (value) {
                   if (value!.isEmpty) {
                     return 'Please enter Description of your problem';
                   }
                 },
               ),

               const SizedBox(
                 height: 10,
               ),

               gfButton(
                 ButtonTitle: 'Submit',
                 onPressed: (){
                   _validate();
                 },
               ),
             ],
           ),
         ),

       ),
     ),
   );
  }

  DropdownButton<String> DropDown() {
    return DropdownButton<String>(
      hint: const Text(
        "City",
        style: kInheritanceTextStyle,
      ),
      value: City.isNotEmpty ? City : null, // guard it with null if empty
      dropdownColor: coloryellowish,
      icon: const Icon(Icons.keyboard_arrow_down),
      elevation: 16,
      style: const TextStyle(color: colorblack),
      onChanged: (String? value) {
        setState(() {
          City = value!;
        });
      },
      items: city.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }

}
