import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:practice/admin_section.dart';
import 'package:practice/home.dart';
import 'package:practice/signup_controller.dart';
import 'package:practice/user_login.dart';
import 'package:practice/user_model.dart';
import 'package:practice/user_repository.dart';
import 'constant.dart';
import 'package:practice/user_section.dart';
import 'main.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'otp_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthenticationRepository extends GetxController {
  static AuthenticationRepository get instance => Get.find();

  // Variables
  final _auth = FirebaseAuth.instance;
  late final Rx<User?> firebaseUser;
  var verificationId = "".obs;
  static String verify = "";
  late String userEmail;
  String? adminCity;
  SharedPreferences? _prefs;

  final controller = Get.put(SignUpController());
  final userRepo = Get.put(UserRepository());

  @override
  void onReady() async {
    _prefs = await SharedPreferences.getInstance();
    firebaseUser = Rx<User?>(_auth.currentUser);
    firebaseUser.bindStream(_auth.userChanges());
    ever(firebaseUser, _setInitialScreen); // Trigger initial screen setup
  }

  // Set initial screen based on user and isAdmin flag
  _setInitialScreen(User? user) {
    bool isAdmin = _prefs?.getBool('isAdmin') ?? false;

    if (user == null && !isAdmin) {
      Get.offAll(() => const Splashscreen()); // Navigate to Splashscreen
    } else if (user != null && !isAdmin) {
      Get.offAll(() =>  userPage()); // Navigate to User Page
    } else if (isAdmin) {
      adminCity = _prefs?.getString('adminCity');
      if (adminCity != null) {
        Get.offAll(() => AdminPage(adminCity: adminCity!)); // Navigate to Admin Page
      }
    }
  }

  //Funtions

  //email authentication
  Future<void> recoverPassword(String email) async {
    _auth.sendPasswordResetEmail(email: email).then((value) {
      Get.snackbar(
        "Email Sent",
        'We have sent you email to recover password, please check email',
        backgroundColor: colormustard,
      );
    }).onError((error, stackTrace) {
      Get.snackbar(
        "Error",
        error.toString(),
        backgroundColor: colormustard,
      );
    });
  }


  // User signup
  Future<bool?> createUserWithEmailAndPassword(UserModel user) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: user.Email.toString(), password: user.Password.toString());
    {  await userRepo.createUser(user);
      firebaseUser.value != null
          ? Get.offAll(() => UserLogin()) // Navigate to UserLogin
          : Get.to(() => const Home()); // Navigate to Home
      return true;
    }
    } on FirebaseAuthException catch (e) {
      Get.snackbar(
        "Error",
        '${e.message}',
        backgroundColor: colormustard,
      );
      return false;
    }
  }


  //User Login
  Future<bool?> loginUserWithEmailAndPassword(
      String email, String password) async {
    await _auth
        .signInWithEmailAndPassword(email: email, password: password)
        .then((value) {
      // Assuming the user's ID is available after successful login
      userEmail = email;
      Get.offAll(() =>  userPage());
      return true;
    }).onError((error, stackTrace) {
      Get.snackbar(
        "Error",
        error.toString(),
        backgroundColor: colormustard,
      );
      return false;
    });
  }

  //Logout
  Future<void> logout() async {
    await _auth.signOut();
  }

  //Admin Login
  Future<bool?> loginAdminWithEmailAndPassword(
      String adminEmail, String adminPhoneNumber, String adminPassword) async {

    try {
      print(adminEmail);
      print(adminPassword);
      print(adminPhoneNumber);
      QuerySnapshot adminSnapshots = await FirebaseFirestore.instance
          .collection("admin")
          .where("adminEmail", isEqualTo: adminEmail)
          .where("adminPhoneNumber", isEqualTo: adminPhoneNumber)
          .where("adminPassword", isEqualTo: adminPassword)
          .get();



      if (adminSnapshots.docs.isNotEmpty) {
        adminCity = adminSnapshots.docs[0].id; // Get the document ID
        sendOtp(adminPhoneNumber);
        _prefs?.setBool('isAdmin', true); // Set isAdmin flag
        _prefs?.setString('adminCity', adminCity!); // Store adminCity
      return true;
      }else {
          Get.snackbar(
            "Error",
            'Invalid email or password',
            backgroundColor: colormustard,
          );
      return false;
        }
    } catch (e) {
      Get.snackbar(
        "Error", e.toString(),
        backgroundColor: colormustard,
      );
    return false;
    }
  }

  //Send OTP
  void sendOtp(String adminPhNo) async {
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: adminPhNo,
        verificationCompleted: (PhoneAuthCredential credential) {},
        codeSent: (String verificationId, int? resendToken) {
          AuthenticationRepository.verify = verificationId;
          Get.offAll(const OtpScreen());
          Get.snackbar("OTP Sent", 'Please Check your inbox',
              backgroundColor: colormustard);
        },
        codeAutoRetrievalTimeout: (String verificationId) {},
        verificationFailed: (FirebaseAuthException error) {
          Get.snackbar(
            "Error",
            error.toString(),
            backgroundColor: colormustard,
          );
        },
      );
    } catch (e) {
      Get.snackbar(
        "Error",
        e.toString(),
        backgroundColor: colormustard,
      );
    }
  }



  // Verify otp
  Future<void> verifyOTP(String otp) async {
    try {
      // Create a PhoneAuthCredential using the verification ID and entered OTP
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: AuthenticationRepository.verify,
        smsCode: otp,
      );

      // Sign in using the credential
      UserCredential adminCredential =
      await FirebaseAuth.instance.signInWithCredential(credential);

      // If sign-in is successful, adminCredential.user will contain the authenticated user
      if (adminCredential.user != null) {
        // Successfully verified, navigate to the admin page
        Get.offAll(() =>
            AdminPage(adminCity: adminCity.toString())); // Navigate to Admin Page
      } else {
        Get.snackbar(
          "Error",
          "Invalid OTP",
          backgroundColor: colormustard,
        );
      }
    } catch (e) {
      Get.snackbar(
        "Error",
        e.toString(),
        backgroundColor: colormustard,
      );
    }
  }


  // admin logout
  Future<void> adminlogout() async {
    await _auth.signOut();
    _prefs?.remove('isAdmin');
    _prefs?.remove('adminCity');
  }

}

