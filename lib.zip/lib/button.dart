import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'constant.dart';

// Custom GFButton with loading indicator support
class gfButton extends StatelessWidget {
  gfButton({
    super.key,
    required this.ButtonTitle,
    required this.onPressed,
    this.loading = false,
  });

  bool loading;
  final String ButtonTitle;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 200.0),
      child: GFButton(
        onPressed: onPressed,
        shape: GFButtonShape.standard,
        size: 50,
        color: colorbluegreyshade,
        boxShadow: BoxShadow(
          color: colorbluegreyshade.withOpacity(0.6),
          spreadRadius: 6,
          blurRadius: 7,
          offset: const Offset(0, 4), // Changes position of shadow
        ),
        child: Center(
          child: loading
              ? const CircularProgressIndicator(
            strokeWidth: 3,
            color: Colors.white,
          ) // Loading indicator
              : Text(ButtonTitle, style: kInheritanceTextStyle),
        ),
      ),
    );
  }
}

// Custom rounded button
class RoundedButton extends StatelessWidget {
  const RoundedButton({
    super.key,
    required this.title,
    required this.onPressed,
  });

  final String title;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Material(
        elevation: 5.0,
        color: colorbluegrey.withOpacity(0.6),
        borderRadius: BorderRadius.circular(30.0),
        child: MaterialButton(
          onPressed: onPressed,
          minWidth: 200.0,
          height: 42.0,
          child: Text(
            title,
            style: kInheritanceTextStyle.copyWith(fontSize: 15, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
