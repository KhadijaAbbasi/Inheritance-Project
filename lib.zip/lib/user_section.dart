import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/authentication_repository.dart';
import 'package:practice/complaint_form.dart';
import 'package:practice/user_complaint_status.dart';
import 'package:practice/constant.dart';

import 'home.dart';

class userPage extends StatefulWidget {

   userPage({Key? key}) : super(key: key);

  @override
  State<userPage> createState() => _userPageState();
}

class _userPageState extends State<userPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          iconTheme: const IconThemeData(
            color: Colors.black, //change your color here
            size: 30,
          ),
          title: Center(
            child: Text('User Section',
              style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
    AuthenticationRepository.instance.logout();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const Home()),
    );
    },
              icon: const Icon(
                Icons.logout_rounded,
              ),
            )
          ],
        ),
        body: Container(
          height: 1000,
          decoration: kBackgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(30, 50, 30, 20),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(children: <Widget>[
                const CircleAvatar(
                  radius: 105,
                  backgroundImage: AssetImage('images/logo_BgRemove.png'),
                  backgroundColor: colormustard,
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: Column(
                    children: [
                      GFButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Complaint()),
                          );
                        },
                        text: "File a new Complaint",
                        textStyle: const TextStyle(
                            fontSize: 20,
                            color: colorblack,
                            fontWeight: FontWeight.w500),
                        shape: GFButtonShape.pills,
                        size: 45,
                        blockButton: true,
                        color: Colors.orange.shade200,
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      GFButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ComplaintStatus()),
                          );
                        },
                        text: "Check your Complaint Status",
                        textStyle: const TextStyle(
                            fontSize: 20,
                            color: colorblack,
                            fontWeight: FontWeight.w500),
                        shape: GFButtonShape.pills,
                        size: 45,
                        blockButton: true,
                        color: Colors.orange.shade200,
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        ));
  }
}