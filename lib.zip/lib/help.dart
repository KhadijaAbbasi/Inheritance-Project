import 'package:flutter/material.dart';
import 'constant.dart';
import 'home.dart';



class Help extends StatefulWidget {
  const Help({Key? key}) : super(key: key);

  @override
  State<Help> createState() => _Help();
}

class _Help extends State<Help> {

  @override

  Widget build(BuildContext context) {
    return  Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        title: const Padding(
            padding: EdgeInsets.only(left:60.0),
            child: Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )
        ),
        elevation: 0.0,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      backgroundColor: colormustard,
      body: Container(
        decoration: kBackgroundDecoration,
        child: const SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              children: <Widget>[
                SizedBox(height: 15),
                Text('Register Complaint',
                    style: kInheritanceTextStyle),
                SizedBox(height: 15),
                Image(
                  image: AssetImage('images/newcomplain.png'),
                ),
                SizedBox(height: 15),
                Text('Check Complaint Status',
                    style: kInheritanceTextStyle),
                SizedBox(height: 15),
                Image(
                  image: AssetImage('images/complainstatus.png'),
                ),
                SizedBox(height: 15),
                Text('Calculate Shares',
                    style: kInheritanceTextStyle),
                SizedBox(height: 15),
                Image(
                  image: AssetImage('images/calculationguide.png'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

