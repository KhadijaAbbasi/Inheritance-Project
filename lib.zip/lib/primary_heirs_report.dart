import 'dart:io';
import 'package:flutter/material.dart';
import 'button.dart';
import 'constant.dart';
import 'home.dart';
import 'primary_heirs.dart';
import 'deceased_data.dart';
import 'secondary_heirs.dart';
import 'primary_heirs_data.dart';
import 'reuseable_Container.dart';
import 'package:getwidget/getwidget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'user_login.dart';
import 'admin_login.dart';
import 'Rules.dart';

class PrimaryHeirsReport extends StatefulWidget {
  const PrimaryHeirsReport({Key? key}) : super(key: key);

  @override
  State<PrimaryHeirsReport> createState() => _PrimaryHeirsReportState();
}

class _PrimaryHeirsReportState extends State<PrimaryHeirsReport> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const PrimaryHeirs()),
            );
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: const Padding(
          padding:  EdgeInsets.only(left: 60.0),
          child: Text(
            'WarisApp',
            style: kAppBarTextStyle,
          ),
        ),
        actions: [
          PopupMenuButton(
            color: colormustard,
            itemBuilder: (context) => [
              PopupMenuItem<int>(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  children: [
                    GestureDetector(
                      child: const Row(
                        children: [
                          Icon(
                            Icons.home,
                            color: colorblack,
                            size: 20.0,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text('Home'),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const Home()),
                      ),
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      child: Row(
                        children: [
                          SizedBox(
                            height: 20,
                            width: 20,
                            child: Image.asset("images/complain.png"),
                          ),
                          const SizedBox(width: 10),
                          const Text('Complaint'),
                        ],
                      ),
                      onTap: () => selectPerson(context),
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      child: const Row(
                        children: [
                          Icon(
                            Icons.receipt_long,
                            color: colorblack,
                            size: 20.0,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text('View Rules'),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ViewRules()),
                      ), // call this to exit app
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      child: const Row(
                        children: [
                          Icon(
                            Icons.exit_to_app,
                            color: colorblack,
                            size: 20.0,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text('Exit'),
                        ],
                      ),
                      onTap: () => exit(0), // call this to exit app
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
        elevation: 0.0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 1,
            child: Container(
              padding: const EdgeInsets.all(15.0),
              child: Text(
                'Shares of Primary Heirs according to Islamic Shariah',
                style: kHeadingTextStyle.copyWith(height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: SingleChildScrollView(
              child: ReuseableContainer(
                colour: Colors.lime.shade50,
                childCard: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Father Shares:",
                      style: kHeadingTextStyle,
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "${firstHeirs.fatherName!} will get Rs.${firstHeirs.fatherShares} from Total Amount which is Rs.${PropertyDetails.Total}",
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 15.0),
                    const Text(
                      "Mother Shares:",
                      style: kHeadingTextStyle,
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "${firstHeirs.motherName!} will get Rs.${firstHeirs.motherShares} from Total Amount which is Rs.${PropertyDetails.Total}",
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 15.0),

                    const Text(
                      "Spouse Shares:",
                      style: kHeadingTextStyle,
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "Spouse will get Rs.${firstHeirs.SpouseShares} each from Total Amount which is Rs.${PropertyDetails.Total}",
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 15.0),
                    const Text(
                      "Daughter Shares:",
                      style: kHeadingTextStyle,
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "Daughters will get Rs.${firstHeirs.daughterShares} each from Total Amount which is Rs.${PropertyDetails.Total}",
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 15.0),
                    const Text(
                      "Son Shares:",
                      style: kHeadingTextStyle,
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "Son will get Rs.${firstHeirs.sonShares} each from Total Amount which is Rs.${PropertyDetails.Total}",
                      style: kAhadithHeadingTextStyle,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 15.0),
                  ],
                ),
              ),
            ),
          ),
          Visibility(
            visible: firstHeirs.ShowNextButton,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30.0, right: 20.0),
              child: gfButton(
                ButtonTitle: 'Next',
                onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Secondaryheirs()),
                    );
                },
              ),
            ),
          ),
          Visibility(
            visible: firstHeirs.ShowReportButton,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30.0, right: 20.0),
              child: gfButton(
                ButtonTitle: 'View Rules',
                onPressed: () {
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  void selectPerson(BuildContext context) {
    var alertDialog = AlertDialog(
      backgroundColor: colormustard,
      title: const Text('Are You?',
          textAlign: TextAlign.center, style: kInheritanceTextStyle),
      content: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        GFButton(
            icon: const Icon(
              FontAwesomeIcons.circleUser,
              size: 20,
            ),
            text: "Admin",
            textStyle: kInheritanceTextStyle,
            shape: GFButtonShape.standard,
            color: colorbluegreyshade,
            size: 40,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AdminLogin()),
              );
            }),
        const SizedBox(width: 10),
        GFButton(
            icon: const Icon(
              FontAwesomeIcons.users,
              size: 20,
            ),
            text: " User ",
            textStyle: kInheritanceTextStyle,
            shape: GFButtonShape.standard,
            color: colorbluegreyshade,
            size: 40,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserLogin()),
              );
            }),
      ]),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }
}
