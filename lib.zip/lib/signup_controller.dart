
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:practice/authentication_repository.dart';
import 'package:practice/complaint_model.dart';
import 'package:practice/user_model.dart';
import 'complaint_controller.dart';


class SignUpController extends GetxController{

  static SignUpController get instance=> Get.find();

  final complaintRepo = Get.put(ComplaintController());

  //user data
  final name = TextEditingController();
  final email = TextEditingController();
  final phonenumber = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();

  //admin data
  final adminEmail = TextEditingController();
  final adminPassword = TextEditingController();
  final adminphoneNo = TextEditingController();
  final otpcontroller = TextEditingController();



  bool? registerUser(UserModel user)
  {
    AuthenticationRepository.instance.createUserWithEmailAndPassword(user);
  }


  bool? loginUser(String email, String password)
  {
    AuthenticationRepository.instance.loginUserWithEmailAndPassword(email, password);
  }

  void recoverPassword(String email)
  {
    AuthenticationRepository.instance.recoverPassword(email);
  }

  bool? loginAdmin(String AdminEmail, String PhNo, String AdminPassword)
  {
    AuthenticationRepository.instance.loginAdminWithEmailAndPassword(AdminEmail, PhNo, AdminPassword);
  }


  Future<bool?> RegisterComplaints(ComplaintModel complaint) async
  {
    await complaintRepo.RegisterComplaint(complaint);
  }

}