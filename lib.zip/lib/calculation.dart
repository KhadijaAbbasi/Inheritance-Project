import 'deceased_data.dart';
import 'primary_heirs_data.dart';
import 'secondary_data.dart';


class SunniSharesCalculation{
  int wifeShares=0;
  int husbandShares=0;
  int flag=0;

  //Primary Heirs Calculation
  void PrimaryHeirs_calculation() {

    if (DeceasedDetails.maritalStatus == 'Married' ) {

      //Husband Shares
      if (DeceasedDetails.gender == 'Female') {
        if (firstHeirs.no_of_son == 0 && firstHeirs.no_of_Daughter == 0
            && firstHeirs.no_of_sister == 0 && firstHeirs.no_of_Brother == 0) {
          husbandShares = PropertyDetails.TotalAmount * 1 ~/ 2; //(x / y).toInt()
        }
        else if (firstHeirs.no_of_son >= 1 || firstHeirs.no_of_Daughter >= 1
            || firstHeirs.no_of_sister >= 1 || firstHeirs.no_of_Brother >= 1) {
          husbandShares = PropertyDetails.TotalAmount * 1 ~/ 4;
        }
        firstHeirs.SpouseShares = husbandShares;
      }

      //Wife shares
      else if (DeceasedDetails.gender == 'Male' && firstHeirs.no_of_wife > 0){
        if (firstHeirs.no_of_son == 0 && firstHeirs.no_of_Daughter == 0) {
          wifeShares =
              (PropertyDetails.TotalAmount * 1 / 4) ~/ firstHeirs.no_of_wife;
        }
        else if (firstHeirs.no_of_son > 0 || firstHeirs.no_of_Daughter > 0) {
          wifeShares =
              (PropertyDetails.TotalAmount * 1 / 8) ~/ firstHeirs.no_of_wife;
        }
        firstHeirs.SpouseShares = wifeShares;
      }
    }

    //Mother Shares
    if (firstHeirs.motherStatus == 'ALive') {
      if (firstHeirs.no_of_Daughter == 0 && firstHeirs.no_of_son == 0
          && firstHeirs.no_of_sister == 0 && firstHeirs.no_of_Brother == 0) {
        firstHeirs.motherShares =
            PropertyDetails.TotalAmount * 1 ~/ 3;
      }
      else if (firstHeirs.no_of_son >= 1 || firstHeirs.no_of_Daughter >= 1
          || firstHeirs.no_of_sister >= 1 || firstHeirs.no_of_Brother >= 1) {
        firstHeirs.motherShares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
      }
    }

    //Father Shares
    if (firstHeirs.fatherStatus == 'ALive') {
      if (firstHeirs.no_of_Daughter == 0 && firstHeirs.no_of_son == 0) {
        PropertyDetails.TotalAmount =  PropertyDetails.TotalAmount - (firstHeirs.SpouseShares + firstHeirs.motherShares);
        firstHeirs.fatherShares = PropertyDetails.TotalAmount;
        return;
      }
      else if (firstHeirs.no_of_son >= 1 || firstHeirs.no_of_Daughter >= 1) {
        firstHeirs.fatherShares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
      }
    }

    PropertyDetails.TotalAmount =
        PropertyDetails.TotalAmount -
            (firstHeirs.SpouseShares + firstHeirs.fatherShares +
                firstHeirs.motherShares);

    if(DeceasedDetails.maritalStatus=='Married')
    {
    //Daughter Shares
    if (firstHeirs.no_of_Daughter == 1 && firstHeirs.no_of_son == 0) {
      firstHeirs.daughterShares =
          PropertyDetails.TotalAmount * 1 ~/ 2;
      PropertyDetails.TotalAmount =
          PropertyDetails.TotalAmount - firstHeirs.daughterShares;
    }
    else if (firstHeirs.no_of_Daughter >= 2 && firstHeirs.no_of_son == 0) {
      firstHeirs.daughterShares =
          PropertyDetails.TotalAmount * 2 ~/ 3;
      PropertyDetails.TotalAmount =
          PropertyDetails.TotalAmount - (firstHeirs.daughterShares);
      firstHeirs.daughterShares =
          firstHeirs.daughterShares ~/ firstHeirs.no_of_Daughter;
    }

    //son and daughter shares
    else if (firstHeirs.no_of_Daughter > 0 && firstHeirs.no_of_son > 0) {
      int variable = firstHeirs.no_of_Daughter + (firstHeirs.no_of_son * 2);
      firstHeirs.daughterShares =
          PropertyDetails.TotalAmount ~/ variable;
      firstHeirs.sonShares =
          ((PropertyDetails.TotalAmount / variable) * 2).toInt();
      PropertyDetails.TotalAmount =
          PropertyDetails.TotalAmount -
              (firstHeirs.daughterShares * firstHeirs.no_of_Daughter);
      PropertyDetails.TotalAmount =
          PropertyDetails.TotalAmount -
              (firstHeirs.sonShares * firstHeirs.no_of_son);
    }

    //Son Shares
    if (firstHeirs.no_of_son == 1 && firstHeirs.no_of_Daughter == 0) {
      firstHeirs.sonShares = PropertyDetails.TotalAmount;
      PropertyDetails.TotalAmount =
          PropertyDetails.TotalAmount - firstHeirs.sonShares;
    }
    else if (firstHeirs.no_of_son >= 1 && firstHeirs.no_of_Daughter == 0) {
      firstHeirs.sonShares =
          PropertyDetails.TotalAmount ~/ firstHeirs.no_of_son;
      PropertyDetails.TotalAmount = PropertyDetails.TotalAmount -
          (firstHeirs.sonShares * firstHeirs.no_of_son);

    }
  }

    if(PropertyDetails.TotalAmount==0)
    {
      firstHeirs.ShowNextButton=false;
      firstHeirs.ShowReportButton=true;
    }

  }

  //Secondary Heirs Calculation
  void SecondaryHeirs_Calculation() {

    //True GrandFather (Dada)
    if (SecondHeirs.grandFatherStatus == 'ALive' && firstHeirs.fatherStatus == 'Dead')
    {
      if (firstHeirs.no_of_son > 0 || firstHeirs.no_of_Daughter > 0) {
        SecondHeirs.grandFatherShares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
      }
      else {
        SecondHeirs.grandFatherShares = PropertyDetails.TotalAmount;
        return;
      }
    }

    //Maternal GrandMother (Nani)
    if (SecondHeirs.M_grandMotherStatus == 'ALive' &&
        firstHeirs.motherStatus == 'Dead' ) {
      if (firstHeirs.no_of_son > 0 || firstHeirs.no_of_Daughter > 0) {
        SecondHeirs.M_grandMotherShares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
      }
    }

    //True GrandMother (Dado)
    if (SecondHeirs.grandMotherStatus == 'ALive' &&
        firstHeirs.motherStatus == 'Dead' &&
        firstHeirs.fatherStatus == 'Dead') {
      if (firstHeirs.no_of_son > 0 || firstHeirs.no_of_Daughter > 0) {
        SecondHeirs.grandMotherShares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
      }
    }

    // Real Sister
    if (firstHeirs.no_of_Daughter == 0 && firstHeirs.no_of_son == 0 &&
        firstHeirs.no_of_Brother == 0
        && firstHeirs.fatherStatus == 'Dead' &&
        SecondHeirs.grandFatherStatus == 'Dead') {
      if (firstHeirs.no_of_sister >= 2) {
        SecondHeirs.SisterShares =
            PropertyDetails.TotalAmount * 2 ~/ 3;
        SecondHeirs.SisterShares =
            SecondHeirs.SisterShares ~/ firstHeirs.no_of_sister;
      }
      else if (firstHeirs.no_of_sister == 1) {
        SecondHeirs.SisterShares =
            PropertyDetails.TotalAmount * 1 ~/ 2;
      }
    }

    if(DeceasedDetails.maritalStatus=='Married')
    {
    //Son's Daughter Shares
    if (firstHeirs.no_of_son == 0 && firstHeirs.no_of_Daughter == 0 &&
        SecondHeirs.Sons_son == 0) {
      if (SecondHeirs.Sons_Daughter >= 2) {
        SecondHeirs.SD_Shares =
            PropertyDetails.TotalAmount * 2 ~/ 3;
        SecondHeirs.SD_Shares =
            SecondHeirs.SD_Shares ~/ SecondHeirs.Sons_Daughter;
      }
      else if (SecondHeirs.Sons_Daughter == 0) {
        SecondHeirs.SD_Shares =
            PropertyDetails.TotalAmount * 1 ~/ 2;
      }
    }
    else if (firstHeirs.no_of_Daughter == 1 && firstHeirs.no_of_son == 0 &&
        SecondHeirs.Sons_son == 0) {
      SecondHeirs.SD_Shares =
          PropertyDetails.TotalAmount * 1 ~/ 6;
      SecondHeirs.SD_Shares =
          SecondHeirs.SD_Shares ~/ SecondHeirs.Sons_Daughter;
    }


    //Son's Son's Daughter
    if (firstHeirs.no_of_son == 0 && firstHeirs.no_of_Daughter == 0
        && SecondHeirs.Sons_son == 0 && SecondHeirs.Sons_Daughter == 0 &&
        SecondHeirs.Sons_Sons_Son == 0) {
      if (SecondHeirs.Sons_Sons_Daughter >= 2) {
        SecondHeirs.SSD_Shares =
            PropertyDetails.TotalAmount * 2 ~/ 3;
        SecondHeirs.SSD_Shares =
            SecondHeirs.SSD_Shares ~/ SecondHeirs.Sons_Sons_Daughter;
      }
      else if (SecondHeirs.Sons_Sons_Daughter == 1) {
        SecondHeirs.Sons_Sons_Daughter =
            PropertyDetails.TotalAmount * 1 ~/ 2;
      }
    }
    else if (firstHeirs.no_of_son == 0 && SecondHeirs.Sons_son == 0 &&
        SecondHeirs.Sons_Sons_Son == 0) {
      if (firstHeirs.no_of_Daughter == 1 || SecondHeirs.Sons_Daughter == 1) {
        SecondHeirs.SSD_Shares =
            PropertyDetails.TotalAmount * 1 ~/ 6;
        SecondHeirs.SSD_Shares =
            SecondHeirs.SSD_Shares ~/ SecondHeirs.Sons_Sons_Daughter;
      }
    }
  }
    // Uterine Sibling


  }

}

class JaffriahSharesCalculation{}