import 'package:flutter/material.dart';

class ReuseableContainer extends StatelessWidget {
  const ReuseableContainer({super.key, required this.colour, this.childCard});

  final Color colour;
  final Widget? childCard;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15.0),
      margin: const EdgeInsets.all(15.0),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: childCard,
    );
  }
}