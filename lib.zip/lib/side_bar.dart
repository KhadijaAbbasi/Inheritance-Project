import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:practice/Rules.dart';
import 'package:practice/constant.dart';
import 'dart:io';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'user_login.dart';
import 'admin_login.dart';
import 'hadith.dart';
import 'about.dart';
import 'help.dart';


class NavBar extends StatefulWidget {
  const NavBar({Key? key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: colormustard,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            child: CircleAvatar(
              backgroundColor: colormustard,
              child: ClipOval(
                child: Image.asset(
                  'images/logo_BgRemove.png',
                  fit: BoxFit.cover,
                  width: 140,
                  height: 140,
                ),
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.orange.shade300,
            ),
          ),
          ListTile(
            leading: const Icon(Icons.description, color: colorblack),
            title: const Text('Islamic Inheritance Rules'),
            onTap: () =>Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ViewRules()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.menu_book, color: colorblack),
            title: const Text('Ahadith related to Faraid'),
            onTap: () =>  Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Hadith()),
            ),
          ),
          ListTile(
              leading: SizedBox(
                height: 30,
                width: 30,
                child: Image.asset("images/complain.png"),
              ),
              title: const Text('Complaint'),
              onTap: () => selectperson(context),
          ),
          Divider(),
          ListTile(
            leading: const Icon(Icons.help, color: colorblack),
            title: const Text('Help'),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => Help()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.info, color: colorblack),
            title: const Text('About'),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => About()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.star, color: colorblack),
            title: const Text('Rating'),
            onTap: () => Rating(context),
          ),
          Divider(),
          ListTile(
            title: const Text('Exit'),
            leading: const Icon(Icons.exit_to_app, color: colorblack),
            onTap: () => exit(0),
          ),
        ],
      ),
    );
  }

 void selectperson(BuildContext context)
 {
   var alertDialog= AlertDialog(
     backgroundColor: colormustard,
     title: Text('Are You?',
       textAlign: TextAlign.center,
       style: kInheritanceTextStyle),
     content: Row(
       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
       children: [
         GFButton(
             icon: Icon(
               FontAwesomeIcons.userCircle,
               size: 20,
             ),
           text: "Admin",
             textStyle:  kInheritanceTextStyle,
             shape: GFButtonShape.standard,
             color: colorbluegreyshade,
             size: 40,
             onPressed: (){
               Navigator.push(
                 context,
                 MaterialPageRoute(builder: (context) => AdminLogin()),
               );
             }
         ),
         SizedBox(width: 10),
         GFButton(
             icon: Icon(
                 FontAwesomeIcons.users,
             size: 20,
             ),
             text: " User ",
             textStyle:  kInheritanceTextStyle,
             shape: GFButtonShape.standard,
             color: colorbluegreyshade,
             size: 40,
             onPressed: (){
               Navigator.push(
                 context,
                 MaterialPageRoute(builder: (context) => UserLogin()),
               );
             }
             ),
   ]
   ),
   );
   showDialog(context: context,
       builder: (BuildContext context){
    return alertDialog;
   }
   );
 }

 void Rating (BuildContext context){
   var alertDialog= AlertDialog(
     backgroundColor: colormustard,
     title: Text('Rate our app',
         textAlign: TextAlign.center,
         style: kInheritanceTextStyle),
     content: RatingBar.builder(
     initialRating: 3,
     minRating: 1,
     direction: Axis.horizontal,
     allowHalfRating: false,
     itemCount: 5,
     itemPadding: EdgeInsets.symmetric(horizontal: 3.0),
     itemBuilder: (context, _) => Icon(
       Icons.star,
       color: Colors.amber,
     ),
     onRatingUpdate: (rating) {
       print(rating);
     },
     ),
   );
   showDialog(context: context,
       builder: (BuildContext context){
         return alertDialog;
       }
   );
 }



}
