class ComplaintModel {
  final String DeceasedName;
  final String DeceasedCNIC;
  final String ComplainerName;
  final String ComplainerRelation;
  final String ComplainerPhNo;
  final String ComplaintCity;
  final String Description;
  final String userEmail;

  // Constructor for creating a ComplaintModel instance
  const ComplaintModel({
    required this.userEmail,
    required this.DeceasedName,
    required this.DeceasedCNIC,
    required this.ComplainerName,
    required this.ComplainerRelation,
    required this.ComplainerPhNo,
    required this.ComplaintCity,
    required this.Description,
  });

  // Convert the object to a JSON format
  toJson() {
    return {
      "userEmail": userEmail,
      "DeceasedName": DeceasedName,
      "DeceasedCNIC": DeceasedCNIC,
      "ComplainerName": ComplainerName,
      "ComplainerRelation": ComplainerRelation,
      "ComplainerPhoneNo": ComplainerPhNo, // Fixed the key name
      "ComplaintCity": ComplaintCity,
      "Description": Description,
    };
  }
}
