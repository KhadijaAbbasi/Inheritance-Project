class SecondHeirs {
  static String? grandMotherName,
      grandFatherName,
      M_grandFathername,
      M_grandMothername,
      grandMotherStatus,
      grandFatherStatus,
      M_grandMotherStatus,
      M_grandFatherStatus;
  static int Sons_son = 0,
      Sons_Daughter = 0,
      Sons_Sons_Daughter = 0,
      Sons_Sons_Son = 0,
      uterineSiblings = 0;
  static int grandMotherShares = 0,
      grandFatherShares = 0,
      M_grandFatherShares = 0,
      M_grandMotherShares = 0,
      SisterShares = 0,
      SS_Shares = 0,
      SD_Shares = 0,
      SSS_Shares = 0,
      SSD_Shares = 0;
}
