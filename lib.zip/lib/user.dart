import 'package:flutter/material.dart';



class selectperson extends StatefulWidget {
  const selectperson({Key? key}) : super(key: key);

  @override
  State<selectperson> createState() => _selectpersonState();
}

class _selectpersonState extends State<selectperson> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(


    );
  }
}
