import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:practice/signup_controller.dart';
import 'authentication_repository.dart';
import 'home.dart';
import 'constant.dart';
import 'button.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({Key? key}) : super(key: key);

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  // GlobalKey to identify and manipulate the form
  final formKey = GlobalKey<FormState>();

  // GetX Controller to handle OTP input
  final controller = Get.put(SignUpController());

  // Firebase Authentication instance
  final FirebaseAuth auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        title: Center(
          child: Text(
            'OTP Verification',
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      body: Container(
        height: 1000,
        decoration: kBackgroundDecoration,
        child: Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 30.0, right: 10.0),
          child: Form(
            // Assign the GlobalKey to the form for validation and manipulation
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Container(
                  height: 200.0,
                  child: Image.asset('images/logo_BgRemove.png'),
                ),
                const SizedBox(
                  height: 10.0,
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 15,),
                  child: Text(
                    "OTP Verification",
                    style: kHeadingTextStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                const Text('Please enter OTP sent on your phone number',
                  style: kAhadithHeadingTextStyle,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30.0,),
                // Pinput widget for OTP input
                Pinput(
                  showCursor: true,
                  length: 6,
                  controller: controller.otpcontroller,
                ),
                const SizedBox(height: 30.0,),
                // RoundedButton to verify the OTP
                RoundedButton(
                  title: 'Verify OTP',
                  onPressed: () async {
                    String otp = controller.otpcontroller.text; // Get the entered OTP
                    if (otp.isNotEmpty) {
                      // Call the verification function here
                      await AuthenticationRepository.instance.verifyOTP(otp);
                    } else {
                      // Show a snackbar if the OTP is empty
                      Get.snackbar("Error", "Please enter the OTP", backgroundColor: colormustard);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
