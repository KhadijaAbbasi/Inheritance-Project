

class DeceasedDetails {
  static String? name; // Name of the deceased
  static String? CNIC; // CNIC of the deceased
  static String? maritalStatus; // Marital status of the deceased
  static String? gender; // Gender of the deceased
  static String? fiqh; // Fiqh of the deceased
  static bool showMaritalStatus = false; // Flag to show marital status
}

// List of gender options
const List<String> Gender = <String>['Male', 'Female'];

// List of marital status options for owner
const List<String> ownerMartialStatus = <String>['Married', 'Unmarried'];

class PropertyDetails {
  static int TotalAmount = 0; // Total amount of the property
  static int Total = 0; // Total value of the property
}
