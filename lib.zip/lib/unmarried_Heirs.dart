import 'package:flutter/material.dart';
import 'package:practice/unmarried_Report.dart';
import 'button.dart';
import 'constant.dart';
import 'deceased_data.dart';
import 'package:flutter/cupertino.dart';
import 'primary_heirs_data.dart';
import 'calculation.dart';
import 'secondary_data.dart';


const List<String> father_Status = <String>['ALive', 'Dead'];
const List<String> mother_Status = <String>['ALive', 'Dead'];
const List<String> grandfather_Status = <String>['ALive', 'Dead'];
const List<String> grandmother_Status = <String>['ALive', 'Dead'];
const List<String> maternal_gf_Status = <String>['ALive', 'Dead'];
const List<String> maternal_gm_Status = <String>['ALive', 'Dead'];


SunniSharesCalculation CalculateSunniShares = SunniSharesCalculation();

class UnmarriedHeirs extends StatefulWidget {
  const UnmarriedHeirs({Key? key}) : super(key: key);

  @override
  State<UnmarriedHeirs> createState() => _UnmarriedHeirsState();
}

class _UnmarriedHeirsState extends State<UnmarriedHeirs> {
  final _formKey = GlobalKey<FormState>();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        title: Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )),
        elevation: 0.0,
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: kBackgroundDecoration,
          child: Padding(
            padding: EdgeInsets.only(left: 5.0, right: 5.0, top: 20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text("Heirs Infromation",
                      style: kHeadingTextStyle.copyWith(fontSize: 30)),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            firstHeirs.fatherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter deceased's Father name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Required';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: firstHeirs.fatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                firstHeirs.fatherStatus = value!;
                              });
                            },
                            items: father_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            firstHeirs.motherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter deceased's Mother name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Required';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: firstHeirs.motherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                firstHeirs. motherStatus = value!;
                              });
                            },
                            items: mother_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.grandFatherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter Grandfather name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Enter Grandfather name';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.grandFatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.grandFatherStatus = value!;
                              });
                            },
                            items: grandfather_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.grandMotherName=value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter Grandmother name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Enter Grandmother name';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.grandMotherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.grandMotherStatus = value!;
                              });
                            },
                            items: grandmother_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.M_grandFathername = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter maternal Grandfather name (Nana)"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Enter maternal Grandfather name';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value:  SecondHeirs.M_grandFatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.M_grandFatherStatus = value!;
                              });
                            },
                            items: maternal_gf_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.M_grandMothername = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter maternal Grandmother name (Nani)"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Enter maternal Grandmother name';
                            else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value:  SecondHeirs.M_grandMotherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.M_grandMotherStatus = value!;
                              });
                            },
                            items: maternal_gm_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    onChanged: (value) {
                      firstHeirs.no_of_sister = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter number of sisters"),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: ((value) {
                      if (value!.isEmpty)
                        return 'Required';
                      else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Text is not allowed';
                      }
                    }),
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    onChanged: (value) {
                      firstHeirs.no_of_Brother = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter number of brothers"),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: ((value) {
                      if (value!.isEmpty)
                        return 'Required';
                      else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Text is not allowed';
                      }
                    }),
                  ),
                  SizedBox(height: 10.0),
                  gfButton(
                    ButtonTitle: 'Calculate',
                    onPressed: () {
                      bool isValid = _formKey.currentState!.validate();
                      if (isValid) { //Form is valid
                        if (firstHeirs.fatherStatus == null || firstHeirs.motherStatus ==
                            null || SecondHeirs.grandMotherStatus == null ||  SecondHeirs.grandFatherStatus == null
                            ||  SecondHeirs.M_grandFatherStatus == null ||  SecondHeirs.M_grandMotherStatus == null) { // Marital status is not selected
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Please Select Status',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: colorblack,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              backgroundColor: Color(0xFFe1c7a0),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        } else {
                          if(DeceasedDetails.fiqh=='Sunni') {
                            CalculateSunniShares.PrimaryHeirs_calculation();
                            CalculateSunniShares.SecondaryHeirs_Calculation();
                          }
                          Loading(context);
                        }
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  void Loading(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          Future.delayed(Duration(seconds:3), () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => UnmarriedHeirsReport()),
            );
          });
          return AlertDialog(
            backgroundColor: colormustard,
            title: Text('Please wait a movement'),
            content: CupertinoActivityIndicator(
                radius: 20.0),
          );
        });


  }
}