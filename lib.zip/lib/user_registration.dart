import 'package:flutter/material.dart';
import 'package:get/get.dart'; // Import Get package
import 'package:practice/constant.dart';
import 'package:practice/signup_controller.dart';
import 'package:practice/user_model.dart';
import 'button.dart';
import 'deceased_data.dart';

class RegistrationPage extends StatefulWidget {
  @override
  _RegistrationPageState createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final _formKey = GlobalKey<FormState>();
  final controller = Get.put(SignUpController()); // Initialize controller

  String countrycode = "+92";
  String? gender;
  bool loading = false;

  // Function to validate and register user
  void validation() {

    bool isValid = _formKey.currentState!.validate();
    if (isValid) {
      // Form is valid,
      if (gender!= null) {
        // create UserModel object
        final user = UserModel(
          FullName: controller.name.text.trim(),
          Email: controller.email.text.trim(),
          Gender: gender,
          PhoneNumber: countrycode + controller.phonenumber.text.trim(),
          Password: controller.password.text.trim(),
        );
        bool? temp = SignUpController.instance.registerUser(user);
        if (temp == true) {
          _formKey.currentState!.reset();
        }
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black,
          size: 30,
        ),
        title: Padding(
          padding: const EdgeInsets.only(left: 60.0),
          child: Text(
            'WarisApp',
            style: kAppBarTextStyle,
          ),
        ),
      ),
      body: Container(
        height: 1000,
        decoration: kBackgroundDecoration,
        child: Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 50),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // TextFormField for Name
                  TextFormField(
                    decoration:
                    kInputDecoration.copyWith(hintText: "Enter your name"),
                    controller: controller.name,
                    keyboardType: TextInputType.text,
                    cursorColor: colorbluegrey,
                    maxLength: 25,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter your Name';
                      }
                      if (!RegExp(r'^[a-z A-Z]+$').hasMatch(value)) {
                        return 'Numbers are not allowed in this field';
                      }
                    },
                  ),
                  SizedBox(height: 20),

                  // TextFormField for Email
                  TextFormField(
                    controller: controller.email,
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter your email"),
                    cursorColor: colorbluegrey,
                    validator: (value) {
                      if (value!.isEmpty) return 'Please enter your email';
                    },
                  ),
                  SizedBox(height: 20),

                  // Dropdown for Gender
                  DropDownDecorationBoxDeceased(
                    child: DropDown(),
                  ),
                  SizedBox(height: 20),

                  // Container for Phone Number
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border.all(color: colorbluegrey, width: 2.0),
                      borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(
                            width: 40,
                            child: Text(
                             "+92",
                            ),
                          ),
                          const Text(
                            "|",
                            style: TextStyle(fontSize: 33, color: Colors.grey),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: TextFormField(
                              keyboardType: TextInputType.phone,
                              controller: controller.phonenumber,
                              decoration: const InputDecoration(
                                counterText: '',
                                border: InputBorder.none,
                                hintText: "Phone Number(3...)",
                                hintStyle: TextStyle(color: Colors.black),
                              ),
                              maxLength: 10,
                              cursorColor: colorbluegrey,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter your phone number';
                                }else if (!RegExp(r'^3+[0-4]+[0-9]')
                                    .hasMatch(value)) {
                                  return 'Invalid Phone number"';
                                }
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // TextFormField for Password
                  TextFormField(
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter your password"),
                    keyboardType: TextInputType.text,
                    cursorColor: colorbluegrey,
                    obscureText: true,
                    controller: controller.password,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter your password';
                      }
                      // Additional password validation logic can be added here
                    },
                  ),
                  SizedBox(height: 20),

                  // TextFormField for Confirm Password
                  TextFormField(
                    decoration: kInputDecoration.copyWith(
                        hintText: "Re-enter password"),
                    keyboardType: TextInputType.text,
                    cursorColor: colorbluegrey,
                    controller: controller.confirmPassword,
                    obscureText: true,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please confirm your password';
                      }
                      if (value != controller.password.text) {
                        return 'Passwords do not match';
                      }
                    },
                  ),
                  SizedBox(height: 20),

                  // Register Button
                  gfButton(
                    ButtonTitle: ' Register ',
                    loading: loading,
                    onPressed: () {
                      print("object");
                      validation();
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // DropdownButton for Gender selection
  DropdownButton<String> DropDown() {
    return DropdownButton<String>(
      hint: const Text(
        "Gender",
        style: kInheritanceTextStyle,
      ),
      value: gender,
      dropdownColor: coloryellowish,
      icon: const Icon(Icons.keyboard_arrow_down),
      elevation: 16,
      style: const TextStyle(color: colorblack),
      onChanged: (String? value) {
        setState(() {
          gender = value!;
        });
      },
      items: Gender.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}
