import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:practice/constant.dart';
import 'package:practice/button.dart';
import 'property_details.dart';
import 'deceased_data.dart';

class DeceasedEntry extends StatefulWidget {
  const DeceasedEntry({Key? key}) : super(key: key);

  @override
  State<DeceasedEntry> createState() => _DeceasedEntryState();
}

class _DeceasedEntryState extends State<DeceasedEntry> {
  final _formKey = GlobalKey<FormState>();

  String? cnic;
  String? name;
  String? gender;
  String? maritalStatus;

  // Function to handle form validation and navigation
  _validation() {
    bool isValid = _formKey.currentState!.validate();
    if (isValid) {
      if (maritalStatus == null) {
        // Marital status is not selected
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Please Select Marital Status',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colorblack,
                fontWeight: FontWeight.w700,
              ),
            ),
            backgroundColor: Color(0xFFe1c7a0),
            duration: Duration(seconds: 2),
          ),
        );
      } else if (gender == null) {
        // Gender is not selected
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Please Select Gender',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colorblack,
                fontWeight: FontWeight.w700,
              ),
            ),
            backgroundColor: Color(0xFFe1c7a0),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        // Populate DeceasedDetails and navigate to propertyDetails screen
        DeceasedDetails.name = name;
        DeceasedDetails.CNIC = cnic;
        DeceasedDetails.gender = gender;
        DeceasedDetails.maritalStatus = maritalStatus;

        // Navigate to propertyDetails screen
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const propertyDetails()),
        );

        // Set showMaritalStatus based on marital status
        if (maritalStatus == 'Married') {
          DeceasedDetails.showMaritalStatus = true;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: GFAppBar(
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(
          color: Colors.white, //change your color here
          size: 30,
        ),
        elevation: 0.0,
        title: const Padding(
          padding: EdgeInsets.only(left: 60.0),
          child: Text(
            "WarisApp",
            style: kAppBarTextStyleOwner,
          ),
        ),
      ),
      body: Container(
        decoration: kBackgroundDecoration,
        child: Column(
          children: [
            // Display Image Overlay
            GFImageOverlay(
              height: 240,
              image: const AssetImage('images/scenery.png'),
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.4),
                BlendMode.darken,
              ),
            ),
            // Display Text and Divider
            const Text(
              "Inheritance Calculation According To Islamic Shariah",
              textAlign: TextAlign.center,
              style: kInheritanceTextStyle,
            ),
            divider,
            const Padding(
              padding: EdgeInsets.only(top: 25, bottom: 15, right: 80.0),
              child: Text(
                "Deceased Information",
                style: kHeadingTextStyle,
              ),
            ),
            // Deceased Entry Form
            Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 30,
                  right: 30,
                ),
                child: Column(
                  children: <Widget>[
                    // CNIC Input Field
                    TextFormField(
                      onChanged: (value) {
                        cnic = value;
                      },
                      decoration: kInputDecoration.copyWith(
                        hintText: "Deceased's CNIC - without dashes",
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 2,
                            color: colorbluegrey,
                          ),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      keyboardType: TextInputType.number,
                      cursorColor: colorbluegrey,
                      maxLength: 13,
                        // Validation logic for CNIC input
                        validator:(value) {
                          if (value!.isEmpty) {
                            return "Please enter deceased CNIC ";
                          } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                            return 'Text is not allowed in this field';
                          }else if (value.length < 13)
                          {
                            return ' CNIC should be of 13 digit';
                          }
                      },
                    ),
                    const SizedBox(height: 22),

                    // Name Input Field
                    TextFormField(
                      onChanged: (value) {
                        name = value;
                      },
                      decoration: kInputDecoration.copyWith(
                        hintText: "Deceased's Name",
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 2,
                            color: colorbluegrey,
                          ),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      keyboardType: TextInputType.text,
                      cursorColor: colorbluegrey,
                      maxLength: 20,
                      validator: (value) {
                        // Validation logic for name input
                        if (value!.isEmpty) {
                          return "Please enter deceased name ";
                        } else if (!RegExp(r'^[a-z A-Z]+$').hasMatch(value)) {
                          return 'Numbers are not allowed in this field';
                        }
                      },
                    ),

                    const SizedBox(height: 22),

                    // Gender and Marital Status Dropdowns
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Gender Dropdown
                        Flexible(
                          child: DropDownDecorationBoxDeceased(
                            child: DropdownButton<String>(
                              // Dropdown properties
                              hint: const Text(
                                "Gender",
                                style: kInheritanceTextStyle,
                              ),
                              value: gender,
                              dropdownColor: coloryellowish,
                              icon: const Icon(Icons.keyboard_arrow_down),
                              elevation: 16,
                              style: const TextStyle(color: colorblack),
                              onChanged: (String? value) {
                                setState(() {
                                  gender = value!;
                                });
                              },
                              items: Gender.map<DropdownMenuItem<String>>(
                                    (String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                },
                              ).toList(),
                            ),
                          ),
                        ),

                        const SizedBox(width: 10.0),

                        // Marital Status Dropdown
                        DropDownDecorationBoxDeceased(
                          child: DropdownButton<String>(
                            // Dropdown properties
                            hint: const Text(
                              " Marital Status",
                              style: kInheritanceTextStyle,
                            ),
                            value: maritalStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                maritalStatus = value!;
                              });
                            },
                            items: ownerMartialStatus.map<DropdownMenuItem<String>>(
                                  (String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              },
                            ).toList(),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 22),

                    // Next Button
                    gfButton(
                      onPressed: () {
                        _validation();
                      },
                      ButtonTitle: "Next",
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
