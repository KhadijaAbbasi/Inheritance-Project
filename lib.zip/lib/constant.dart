import 'package:flutter/material.dart';
import 'package:flutter/src/material/colors.dart';


//Colors
const coloryellowish = Color(0xFFFFFDE7);
const colorbluegrey = Color(0xFF455A64); //Colors.blueGrey.shade700
const colorbluegreyshade = Color(0xFF90A4AE);
const colorblack = Colors.black;
const colorgrey = Color(0xFF9E9E9E);
const colorwhite = Colors.white;
const colormustard =  Color(0xFFf6edd3);//backgroundcolor


const kAppBarTextStyle = TextStyle(fontSize: 22, color: colorblack, fontWeight: FontWeight.w700);

const kAppBarTextStyleOwner = TextStyle(
  color: colorwhite,
  fontSize: 22,
  fontWeight: FontWeight.w500,
);

const divider = Divider(
  thickness: 2,
  indent: 25,
  endIndent: 25,
  color: Colors.blueGrey,
);

const kInheritanceTextStyle = TextStyle(
    color: colorblack,
    fontSize: 20,
    fontWeight: FontWeight.bold,
    fontStyle: FontStyle.normal,
    height: 1.6);

const kStatusDropDown = TextStyle(
    color: colorblack,
    fontSize: 17,
    fontWeight: FontWeight.bold,
    fontStyle: FontStyle.normal,
    height: 1);

const kHeadingTextStyle = TextStyle(
    decoration: TextDecoration.none,
    fontSize: 20,
    fontWeight: FontWeight.w900,
    fontStyle: FontStyle.italic,
    height: 1);

const kAhadithHeadingTextStyle = TextStyle(
    decoration: TextDecoration.none,
    fontSize: 18,
    height: 1.3);

const kAhadithTextStyle = TextStyle(
    decoration: TextDecoration.none,
    fontSize: 17,
    fontWeight: FontWeight.w900,
    fontStyle: FontStyle.italic,
    height: 1.3);

//Background Image
const kBackgroundDecoration = BoxDecoration(
  image: DecorationImage(
    image: AssetImage("images/background.png"),
    fit: BoxFit.cover,
  ),
);


const kInputDecoration = InputDecoration(
  counterText: '',
  hintText: "Enter a value",
  hintStyle: TextStyle(
    color: Colors.black,
  ),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(width: 2.0,
        color: colorbluegrey),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(
      color: colorbluegrey,
      width: 2.0,
    ),
  ),
);



const kTextFieldDecoration = InputDecoration(
  counterText: '',
  hintText: 'Enter a value',
  contentPadding:
  EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(color: colorbluegrey, width: 2.0),
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(color: colorbluegrey, width: 2.0),
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
);


const String kotpTitle ="CO\nDE";
const String kotpSubTitle ="Verification";
const String kotpMessage ="Enter the verification code sent at ";


class DropDownDecorationBoxDeceased extends StatelessWidget {
  DropDownDecorationBoxDeceased({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
          color: Colors.orange.shade100
              .withOpacity(0.8), //background color of dropdown button
          border: Border.all(
              color: colorbluegrey, width: 2), //border of dropdown button
          borderRadius: BorderRadius.circular(10),
          //border radius of dropdown button
          boxShadow: const <BoxShadow>[
            //apply shadow on Dropdown button
            BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.57), //shadow for button
                blurRadius: 5) //blur radius of shadow
          ]),
      child: Center(child: child),
    );
  }
}

class DropDownDecorationBox extends StatelessWidget {
  DropDownDecorationBox({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
          color: Colors.orange.shade100
              .withOpacity(0.8), //background color of dropdown button
          border: Border.all(
              color: colorbluegrey, width: 2), //border of dropdown button
          borderRadius: BorderRadius.circular(5),
          //border radius of dropdown button
          boxShadow: const <BoxShadow>[
            //apply shadow on Dropdown button
            BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.57), //shadow for button
                blurRadius: 5) //blur radius of shadow
          ]),
      child: Center(child: child),
    );
  }
}

