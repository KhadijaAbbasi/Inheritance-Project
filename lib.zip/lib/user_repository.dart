import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:practice/user_model.dart';
import 'constant.dart';

class UserRepository extends GetxController{
  static UserRepository get instance => Get.find();

  final _db = FirebaseFirestore.instance;

  createUser (UserModel user) async{
  await _db.collection("Users").add(user.toJson()).whenComplete(() =>
        Get.snackbar("Success", 'Your account has been created',
        backgroundColor: colormustard),
    ).catchError((error, stackTrace)
    {
      Get.snackbar("Error", error.toString(),
          backgroundColor: colormustard);
    });
  }
  
}