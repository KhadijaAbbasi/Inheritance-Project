import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:getwidget/getwidget.dart';
import 'complaint_controller.dart';
import 'constant.dart';
import 'package:get/get.dart';

class ComplaintsData extends StatefulWidget {
  final String adminCity; // Received adminCity from adminPage
  final VoidCallback? onComplaintMoved; // Add this line

  const ComplaintsData({super.key, required this.adminCity,this.onComplaintMoved,});

  @override
  _ComplaintsDataState createState() => _ComplaintsDataState();
}

class _ComplaintsDataState extends State<ComplaintsData> {
  String searchText = ''; // The text entered in the search bar
  String searchBy = 'name'; // Default search by name


  late List<QueryDocumentSnapshot<Map<String, dynamic>>> filteredDocs;
  final complaintRepository = Get.put(ComplaintController());


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: GFAppBar(
        backgroundColor: Colors.orange.shade300,
        iconTheme: const IconThemeData(
          color: colorblack,
          size: 30,
        ),
        title: const Padding(
          padding: EdgeInsets.only(left:60.0),
          child: Text(
            "Admin Panel",
            style: kAppBarTextStyle,
          ),
        ),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection("Complaints")
            .where("ComplaintCity", isEqualTo: widget.adminCity) // Filter by adminCity
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final docs = snapshot.data!.docs;


            filteredDocs = docs.where((doc) {
              final data = doc.data();
              final complainerName = data['ComplainerName']?.toString().toLowerCase() ?? '';
              final userEmail = data['userEmail']?.toString().toLowerCase() ?? '';



              // Search by either ComplainerName or userEmail based on dropdown selection
              return searchBy == 'name'
                  ? complainerName.contains(searchText.toLowerCase())
                  : userEmail.contains(searchText.toLowerCase());
            }).toList();

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // Title: "User Complaints"
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text(
                      "User Complaints",
                      style: kHeadingTextStyle,
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          onChanged: (value) {
                            setState(() {
                              searchText = value; // Update search text here
                            });
                          },
                          decoration: InputDecoration(
                            hintText: searchBy == 'name'
                                ? 'Search by complainer name'
                                : 'Search by Complainer ID',
                            prefixIcon: const Icon(Icons.search),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      DropdownButton<String>(
                        value: searchBy,
                        onChanged: (value) {
                          setState(() {
                            searchBy = value!;
                            searchText = ''; // Reset search text when changing criteria
                          });
                        },
                        items: const [
                          DropdownMenuItem<String>(
                            value: 'name',
                            child: Text('Name'),
                          ),
                          DropdownMenuItem<String>(
                            value: 'ID',
                            child: Text('ID'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView.builder(
                    itemCount: filteredDocs.length,
                    itemBuilder: (context, i) {
                      final data = filteredDocs[i].data();
                      final documentId = filteredDocs[i].id; // Get the document ID


                      // Extracting complaint data
                      final complainerID = data['userEmail'] ?? 'N/A';
                      final complainerName = data['ComplainerName'] ?? 'N/A';
                      final complainerPhoneNo = data['ComplainerPhoneNo'] ?? 'N/A';
                      final complaintCity = data['ComplaintCity'] ?? 'N/A';
                      final complainerRelation = data['ComplainerRelation'] ?? 'N/A';
                      final deceasedName = data['DeceasedName'] ?? 'N/A';
                      final deceasedCNIC = data['DeceasedCNIC'] ?? 'N/A';
                      final description = data['Description'] ?? 'N/A';

                      return Container(
                        width: 250,
                        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        color: colormustard,
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              // Displaying complaint details
                              Text("Complainer ID: $complainerID"),
                              const SizedBox(height: 10),
                              Text("Complainer Name: $complainerName"),
                              const SizedBox(height: 10),
                              Text("Complainer Phone No: $complainerPhoneNo"),
                              const SizedBox(height: 10),
                              Text("Complaint City: $complaintCity"),
                              const SizedBox(height: 10),
                              Text("Deceased Name: $deceasedName"),
                              const SizedBox(height: 10),
                              Text("Deceased CNIC: $deceasedCNIC"),
                              const SizedBox(height: 10),
                              Text("Complainer Relation with deceased: $complainerRelation"),
                              const SizedBox(height: 10),
                              Text("Description: $description"),
                              const  SizedBox(height: 10),

                              const Divider(),

                              //Delete Button
                              InkWell(
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        backgroundColor: colormustard,
                                        title: const Text("Confirm Deletion",
                                            style: kInheritanceTextStyle),
                                        content: const Text("Are you sure you want to delete this record?"),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.pop(context); // Close the alert dialog
                                            },
                                            child: const Text("Cancel"),
                                          ),
                                          TextButton(
                                            onPressed: () async {
                                              final complaintData = {
                                                // Construct a map of complaint data from the current document
                                                "userEmail": complainerID,
                                                "DeceasedName": deceasedName,
                                                "DeceasedCNIC": deceasedCNIC,
                                                "ComplainerName": complainerName,
                                                "ComplainerRelation": complainerRelation,
                                                "ComplainerPhoneNo": complainerPhoneNo,
                                                "ComplaintCity": complaintCity,
                                                "Description": description,
                                              };

                                              // Move complaint to Resolve Complaints collection
                                              final success = await complaintRepository.moveComplaintToResolved(documentId, complaintData);

                                              //Record Deleted
                                              if (success) {
                                                FirebaseFirestore.instance
                                                    .collection('Complaints')
                                                    .doc(documentId)
                                                    .delete()
                                                    .then((_) {
                                                  Get.snackbar("Success", "Record deleted and moved to Resolve Complaints",
                                                      backgroundColor: colormustard);
                                                  Navigator.pop(context);
                                                }).catchError((error) {
                                                  Get.snackbar("Error deleting document", "$error",
                                                      backgroundColor: colormustard);
                                                });
                                                widget.onComplaintMoved?.call();
                                              } else {
                                                Get.snackbar("Error", "Failed to move complaint to Resolve Complaints",
                                                    backgroundColor: colormustard);
                                              }
                                            },
                                            child: const Text("Delete"),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                                child: const Align(
                                  alignment: Alignment.bottomRight,
                                  child: Padding(
                                    padding:  EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
