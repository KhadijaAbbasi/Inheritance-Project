import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:getwidget/getwidget.dart';
import 'constant.dart';

class Services extends StatefulWidget {
  const Services({Key? key}) : super(key: key);

  @override
  State<Services> createState() => _ServicesState();
}

class _ServicesState extends State<Services> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: GFAppBar(
          iconTheme: IconThemeData(
            color: Colors.black, //change your color here
            size: 30,
          ),
          title: Padding(
            padding: const EdgeInsets.only(left:60.0),
            child: Text(
              "WarisApp",
              style: kAppBarTextStyle,
            ),
          ),
        ),
        body: Container(
            height: 1000,
            decoration: kBackgroundDecoration,
            child: Center(
              child: Text(
                'Services Currently Not Available!',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 21,
                  color: Colors.black.withOpacity(0.5),
                  fontStyle: FontStyle.italic,
                ),
              ),
            )));
  }
}
