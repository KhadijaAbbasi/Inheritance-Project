import 'package:flutter/material.dart';
import 'constant.dart';
import 'package:getwidget/getwidget.dart';
import 'home.dart';


class Hadith extends StatefulWidget {
  const Hadith({Key? key}) : super(key: key);

  @override
  State<Hadith> createState() => _HadithState();
}

class _HadithState extends State<Hadith> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      extendBodyBehindAppBar: true,
      appBar: GFAppBar(
        backgroundColor: Colors.orange.shade300,
        iconTheme: const IconThemeData(
          color: colorblack, //change your color here
          size: 30,
        ),
        title: Center(
          child: Text("Islamic Inheritance",
            style:kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      body: const Padding(
        padding: EdgeInsets.only(left:8.0,right:8.0,top:120),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
           child:
          Column(
            children: [
              Text('Ahadith Related to Islamic Inheritance',
                style: kHeadingTextStyle,
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 20),
              Divider(),

              Text('1.  The Holy Prophet (saw) has advised Muslims to learn the principles of inheritance by saying:',
                  style: kAhadithHeadingTextStyle,
             ),
            Text('\n“Learn the knowledge related to inheritance and teach it to others, as this constitutes half of all knowledge"'
              '\n~(Sunan Ibn Majah)',
                  style: kAhadithTextStyle,
              textAlign: TextAlign.center,
                ),

              SizedBox(height: 20),
              Divider(),

              Text('2.  Hazrat Mohammad (P.B.U.H) warned the Muslims, not to neglect the knowledge of Inheritance calculation and distribution by saying:',
                  style: kAhadithHeadingTextStyle,
              ),
              Text('\n“Learn Inheritance (Faraid) knowledge and teach it to others.'
                ' I will die, this knowledge will die and will have chaos. So, when the two clashed for the estate, they could not find anyone who can solve their cases" '
                '\n~(Hadith narrated by al-Hakim from Ibnu Mas\'ud)',
                style: kAhadithTextStyle,
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 20),
              Divider(),

              Text('3.  Narrated by Ibn \'Abbas: '
              'The Prophet (P.B.U.H) said:',
                style: kAhadithHeadingTextStyle,
              ),
              Text('\n"Give the Fara\'id (the shares of the inheritance that are prescribed in the Qur\'an) to those who are entitled to receive it.'
                'Then whatever remains, should be given to the closest male relative of the deceased"'
              '\n~(Sahih Bukhari: Volume 8, Book 80, Number 724)',
                style: kAhadithTextStyle,
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 20),
              Divider(),


              Text('4.  As reported by Abu Dawood and Ibn Majah, may Allah have mercy upon them, on the authority of \‘Abdullaah ibn \‘Amr, may Allah be pleased with him, that the Prophet, sallallahu \‘alayhi wa sallam, said:',
                style: kAhadithHeadingTextStyle,
              ),
              Text('\n“Three things are essential to learn, and what is beyond them is just favorably optional: \n a precise (Quranic) Verse, a standing Sunnah or a just prescribed obligatory share (of inheritance).”',
                style: kAhadithTextStyle,
                textAlign: TextAlign.center,
              ),


              SizedBox(height: 20),
              Divider(),


              Text('5.  Narrated by Abu Huraira,'
                'The Prophet (P.B.U.H) said:',
                style: kAhadithHeadingTextStyle,
              ),
              Text('\n"If somebody dies (among the Muslims) leaving some property, the property will go to his heirs; and if he leaves a debt or dependants, we will take care of them"'
                '\n~(Sahih Bukhari: Volume 8, Book 80, Number 755)',
                style: kAhadithTextStyle,
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 20),
              Divider(),

              Text('6.  Narrated Usama bin Zaid,'
                  'The Prophet (P.B.U.H) said:',
                style: kAhadithHeadingTextStyle,
              ),
              Text('\n "A Muslim cannot be the heir of a disbeliever, nor can a disbeliever be the heir of a Muslim"'
                  '\n~(Sahih Bukhari: Volume 8, Book 80, Number 756)',
                style: kAhadithTextStyle,
                textAlign: TextAlign.center,
              ),


            ],
          ),
        ),
      ),
    );
  }
}
