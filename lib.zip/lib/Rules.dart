import 'package:flutter/material.dart';
import 'constant.dart';
import 'home.dart';



class ViewRules extends StatefulWidget {
  const ViewRules({Key? key}) : super(key: key);

  @override
  State<ViewRules> createState() => _ViewRulesState();
}

class _ViewRulesState extends State<ViewRules> {

  @override

  Widget build(BuildContext context) {
    return  Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        title: const Padding(
            padding: EdgeInsets.only(left:60.0),
            child:  Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )
        ),
        elevation: 0.0,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      backgroundColor: colormustard,
      body: Container(
        decoration: kBackgroundDecoration,
        child: const SingleChildScrollView(
          child: Padding(
            padding:  EdgeInsets.all(10),
            child: Column(
             children: <Widget>[
                Text('Sunni Fiqh',
                    style: kInheritanceTextStyle),
                SizedBox(height: 15),
                Image(
                  image: AssetImage('images/sunni.png'),
                ),
               SizedBox(height: 15),
               Text('Jaffriah Fiqh',
                    style: kInheritanceTextStyle),
               SizedBox(height: 15),
               Image(
                  image: AssetImage('images/sunni.png'),
                ),
                ],
            ),
          ),
        ),
      ),
    );
  }
}

