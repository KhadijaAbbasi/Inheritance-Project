import 'package:flutter/material.dart';
import 'package:practice/deceased_data.dart';
import 'package:practice/secondary_data.dart';
import 'button.dart';
import 'constant.dart';
import 'home.dart';
import 'package:flutter/cupertino.dart';
import 'secondary_heirs_Report.dart';
import 'calculation.dart';
import 'primary_heirs_report.dart';

const List<String> grandfather_Status = <String>['ALive', 'Dead'];
const List<String> grandmother_Status = <String>['ALive', 'Dead'];
const List<String> maternal_gf_Status = <String>['ALive', 'Dead'];
const List<String> maternal_gm_Status = <String>['ALive', 'Dead'];

SunniSharesCalculation calculateSecondaryShares = SunniSharesCalculation();

class Secondaryheirs extends StatefulWidget {
  const Secondaryheirs({Key? key}) : super(key: key);

  @override
  State<Secondaryheirs> createState() => _SecondaryheirsState();
}

class _SecondaryheirsState extends State<Secondaryheirs> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colormustard,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, //change your color here
          size: 30,
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const PrimaryHeirsReport()),
            );
          },
          icon: Icon(
            Icons.arrow_back,
          ),
        ),
        title: const Padding(
            padding: EdgeInsets.only(left: 60.0),
            child: Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
        elevation: 0.0,
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: kBackgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0, top: 20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text("Secondary heirs",
                      style: kHeadingTextStyle.copyWith(fontSize: 30)),
                  const SizedBox(height: 15.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.grandFatherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter Grandfather name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Enter Grandfather name';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.grandFatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.grandFatherStatus = value!;
                              });
                            },
                            items: grandfather_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.grandMotherName = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter Grandmother name"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Enter Grandmother name';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.grandMotherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.grandMotherStatus = value!;
                              });
                            },
                            items: grandmother_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.M_grandFathername = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText:
                                  "Enter maternal Grandfather name (Nana)"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Enter maternal Grandfather name';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.M_grandFatherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.M_grandFatherStatus = value!;
                              });
                            },
                            items: maternal_gf_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  Row(
                    children: [
                      Flexible(
                        flex: 3,
                        child: TextFormField(
                          onChanged: (value) {
                            SecondHeirs.M_grandMothername = value;
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText:
                                  "Enter maternal Grandmother name (Nani)"),
                          keyboardType: TextInputType.text,
                          maxLength: 20,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Enter maternal Grandmother name';
                            } else if (!RegExp(r'^[a-z A-Z]').hasMatch(value)) {
                              return 'Numbers are not allowed';
                            }
                          }),
                        ),
                      ),
                      const SizedBox(width: 5.0),
                      Flexible(
                        child: DropDownDecorationBox(
                          child: DropdownButton<String>(
                            hint: const Text(
                              "Status",
                              style: kStatusDropDown,
                            ),
                            value: SecondHeirs.M_grandMotherStatus,
                            dropdownColor: coloryellowish,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            elevation: 16,
                            style: const TextStyle(color: colorblack),
                            onChanged: (String? value) {
                              setState(() {
                                SecondHeirs.M_grandMotherStatus = value!;
                              });
                            },
                            items: maternal_gm_Status
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  Visibility(
                    visible: DeceasedDetails.showMaritalStatus,
                    child: Column(
                      children: [
                        TextFormField(
                          onChanged: (value) {
                            SecondHeirs.Sons_son = int.parse(value);
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter number of Son's son"),
                          keyboardType: TextInputType.number,
                          maxLength: 2,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Required';
                            } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                              return 'Text is not allowed';
                            }
                          }),
                        ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            SecondHeirs.Sons_Daughter = int.parse(value);
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter number of Son's Daughter"),
                          keyboardType: TextInputType.number,
                          maxLength: 2,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Required';
                            } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                              return 'Text is not allowed';
                            }
                          }),
                        ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            SecondHeirs.Sons_Sons_Son = int.parse(value);
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter number of Son's Son's Son"),
                          keyboardType: TextInputType.number,
                          maxLength: 2,
                          validator: ((value) {
                            if (value!.isEmpty)
                              return 'Required';
                            else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                              return 'Text is not allowed';
                            }
                          }),
                        ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            SecondHeirs.Sons_Sons_Daughter = int.parse(value);
                          },
                          decoration: kInputDecoration.copyWith(
                              hintText: "Enter number of Son's Son's Daughter"),
                          keyboardType: TextInputType.number,
                          maxLength: 2,
                          validator: ((value) {
                            if (value!.isEmpty) {
                              return 'Required';
                            } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                              return 'Text is not allowed';
                            }
                          }),
                        ),
                        const SizedBox(height: 10.0),
                      ],
                    ),
                  ),
                  TextFormField(
                    onChanged: (value) {
                      SecondHeirs.uterineSiblings = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter number of Uterine Siblings"),
                    keyboardType: TextInputType.number,
                    maxLength: 2,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return 'Required';
                      } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Text is not allowed';
                      }
                    }),
                  ),
                  const SizedBox(height: 15.0),
                  gfButton(
                    ButtonTitle: 'Calculate',
                    onPressed: () {
                      bool isValid = _formKey.currentState!.validate();
                      if (isValid) {
                        //Form is valid
                        if (SecondHeirs.grandMotherStatus == null ||
                            SecondHeirs.grandFatherStatus == null ||
                            SecondHeirs.M_grandFatherStatus == null ||
                            SecondHeirs.M_grandMotherStatus == null) {
                          // Marital status is not selected
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Please Select Status',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: colorblack,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              backgroundColor: Color(0xFFe1c7a0),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        } else {
                          calculateSecondaryShares.SecondaryHeirs_Calculation();
                          loading(context);
                        }
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void loading(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          Future.delayed(const Duration(seconds: 3), () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const SecondaryHeirsReport()),
            );
          });
          return const AlertDialog(
            backgroundColor: colormustard,
            title: Text('Please wait a movement'),
            content: CupertinoActivityIndicator(radius: 20.0),
          );
        });
  }
}
