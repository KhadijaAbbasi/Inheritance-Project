import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:practice/home.dart';
import 'package:practice/signup_controller.dart';
import 'constant.dart';
import 'button.dart';

class PasswordRecover extends StatefulWidget {
  const PasswordRecover({Key? key}) : super(key: key);

  static String verify = ""; // Static variable to store verification code

  @override
  State<PasswordRecover> createState() => _PasswordRecoverState();
}

class _PasswordRecoverState extends State<PasswordRecover> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();

  final controller = Get.put(SignUpController());

  void validation() async {
    bool isValid = _formKey.currentState!.validate();
    if (isValid) {
      // Form is valid, initiate password recovery
      SignUpController.instance.recoverPassword(_emailController.text.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Change your color here
          size: 30,
        ),
        title: Center(
          child: Text(
            'Reset Password',
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()),
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      body: Container(
        height: 1000,
        decoration: kBackgroundDecoration,
        child: Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 30.0, right: 10.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SizedBox(
                  height: 200.0,
                  child: Image.asset('images/logo_BgRemove.png'),
                ),
                const SizedBox(
                  height: 10.0,
                ),
                const Padding(
                  padding: EdgeInsets.only(
                    top: 5,
                    bottom: 15,
                  ),
                  child: Text(
                    "Email Verification",
                    style: kHeadingTextStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
                const Text(
                  'We need your email id before getting started!',
                  style: kAhadithHeadingTextStyle,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 30.0,
                ),

                TextFormField(
                  controller: _emailController,
                  decoration: kInputDecoration.copyWith(
                      hintText: "Enter your email"),
                  cursorColor: colorbluegrey,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your email';
                    }
                  },
                ),

                const SizedBox(
                  height: 20.0,
                ),

                RoundedButton(
                  title: 'SEND LINK',
                  onPressed: () {
                    validation();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
