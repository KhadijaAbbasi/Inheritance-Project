import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:practice/forgot_password.dart';
import 'package:practice/signup_controller.dart';
import 'user_registration.dart';
import 'constant.dart';
import 'button.dart';
import 'package:practice/home.dart';


class UserLogin extends StatefulWidget {
  @override
  _UserLoginState createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {

  final _formKey = GlobalKey<FormState>(); // GlobalKey for form validation
  final controller = Get.put(SignUpController());// State management using GetX



  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();


  void _validation() async {
    bool isValid = _formKey.currentState!.validate(); // Validate form fields
    // If form is valid
    if (isValid) {
      // Call the loginUser method to attempt login
      bool? temp = SignUpController.instance.loginUser(
          _emailController.text.trim(), _passwordController.text.trim());
      if(temp == true){
        _formKey.currentState!.reset();
    }
  }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Change app bar icon color
          size: 30,
        ),
        title: Center(
          child: Text(
            'User Login',
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Home()), // Navigate to Home screen
              );
            },
            icon: const Icon(
              Icons.home,
            ),
          )
        ],
      ),
      body: Container(
        height: 1000,
        decoration: kBackgroundDecoration, // background decoration
        child: Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 70.0, right: 10.0),
          child: Form(
            key: _formKey, // form key for validation
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 200.0,
                  child: Image.asset('images/logo_BgRemove.png'), // Display logo
                ),
                const SizedBox(
                  height: 30.0,
                ),

                TextFormField(
                  controller: _emailController,
                  decoration: kTextFieldDecoration.copyWith(
                      hintText: "Enter your email"), // Email input field
                  cursorColor: colorbluegrey,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your email';
                    } else if(!RegExp(r'^[a-z A-Z 0-9]+@gmail+.com+$')
                        .hasMatch(value)) {
                      return 'Email must contain "@gmail.com"';
                    }
                  },
                ),

                const SizedBox(
                  height: 10.0,
                ),
                TextFormField(
                  decoration: kTextFieldDecoration.copyWith(
                      hintText: "Enter your password"), // Password input field
                  cursorColor: colorbluegrey,
                  controller: _passwordController,
                  obscureText: true,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter password ";
                    }
                  },
                ),
                const SizedBox(
                  height: 10.0,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      // Navigate to password recovery screen
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const PasswordRecover()),
                      );
                    },
                    child: const Text(
                      "Forgot Password?",
                      style: TextStyle(fontSize: 15.0, color: Colors.blue),
                    ),
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: RoundedButton(
                    title: 'Log In',
                    onPressed: () {
                      _validation(); // Validate and initiate login process
                    },
                  ),
                ),
                SizedBox(
                  height: 5.0,
                ),
                const Text(
                  "OR",
                  style: TextStyle(fontSize: 15.0),
                ),
                SizedBox(
                  height: 5.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const Text('Does not have account? '),
                    GestureDetector(
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(fontSize: 20, color: Colors.blue),
                      ),
                      onTap: () {
                        // Navigate to user registration screen
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RegistrationPage()),
                        );
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
