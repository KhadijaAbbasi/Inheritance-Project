import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'button.dart';
import 'constant.dart';
import 'deceased_data.dart';
import 'liabilities.dart';

class propertyDetails extends StatefulWidget {
  const propertyDetails({Key? key}) : super(key: key);


  @override
  State<propertyDetails> createState() => _propertyDetails();
}

class _propertyDetails extends State<propertyDetails> {
  final _formKey = GlobalKey<FormState>();

  int Total_Amount=0;

  @override
  int? land_price;
  int? vehicles_price;
  int? houses_price;
  int? jewellery_price;
  int? others_price;
  int? gift_price;

  //Deceased Total wealth
  void sum() {
   Total_Amount = land_price! + vehicles_price! + houses_price! + jewellery_price! + others_price! + gift_price!;
    PropertyDetails.Total=Total_Amount;
   assetsWorth(context);
  }

  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
       appBar: AppBar(
         iconTheme: const IconThemeData(
           color: Colors.black, //change your color here
           size: 30,
         ),
        title: const Padding(
            padding: EdgeInsets.only(left:60.0),
            child: Text(
              'WarisApp',
              style: kAppBarTextStyle,
            )
        ),
        elevation: 0.0,
      ),
      backgroundColor: colormustard,
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: kBackgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  const Text("Deceased\'s Property Details",
                    style: kHeadingTextStyle,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      houses_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter House Price (of all houses own)"),
                    keyboardType: TextInputType.number,
                    maxLength: 20,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return 'Enter House Price (of all houses own)';
                      } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                        return 'Invalid House Price';
                      }
                    }),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      jewellery_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: 'Enter Jewellery Price'),
                    keyboardType: TextInputType.number,
                    cursorColor: colorbluegrey,
                    maxLength: 25,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return "Enter jewellery price ";
                      } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'Text is not allowed in this field';
                      }
                    }),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      land_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Enter Current Land Price"),
                    keyboardType: TextInputType.number,
                    maxLength: 25,
                    cursorColor: colorbluegrey,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Enter land price ";
                      } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'Text is not allowed in this field';
                      }
                    },
                  ),
                  const SizedBox(
                    height: 22,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      vehicles_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Price of Vehicles owned"),
                    keyboardType: TextInputType.number,
                    cursorColor: colorbluegrey,
                    maxLength: 25,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return "Enter vehicle price ";
                      } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'Text is not allowed in this field';
                      }
                    }),
                  ),
                  const SizedBox(
                    height: 22,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      others_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Price of Livestock owned or others"),
                    keyboardType: TextInputType.number,
                    cursorColor: colorbluegrey,
                    maxLength: 25,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return "Enter price of livestock or others ";
                      } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'Text is not allowed in this field';
                      }
                    }),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    onChanged: (value) {
                      gift_price = int.parse(value);
                    },
                    decoration: kInputDecoration.copyWith(
                        hintText: "Price of Gifts owned by deceased"),
                    keyboardType: TextInputType.number,
                    maxLength: 20,
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return 'Enter gift Price owned by deceased';
                      } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'Text are not allowed in this field';
                      }
                    }),
                  ),
                  const SizedBox(
                    height: 22,
                  ),
                  gfButton(
                    ButtonTitle: 'Next',
                    onPressed: () {
                      bool isValid = _formKey.currentState!.validate();
                      if (isValid) {//Form is valid
                        sum();
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }



  void assetsWorth (BuildContext context)
  {
    var alertDialog= AlertDialog(
      backgroundColor: colormustard,
      title: Text('Total Assets Worth is Rs.${Total_Amount}',
          textAlign: TextAlign.center,
          style: kInheritanceTextStyle),
      content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            GFButton(
                icon: const Icon(
                  Icons.cancel,
                  size: 20,
                ),
                text: "Cancel",
                textStyle:  kInheritanceTextStyle,
                shape: GFButtonShape.standard,
                color: colorbluegreyshade,
                size: 40,
                onPressed: (){
                  Navigator.pop(context);
                }
            ),
            const SizedBox(width: 10),
            GFButton(
                icon: const Icon(
                Icons.check_circle,
                  size: 20,
                ),
                text: "OK ",
                textStyle:  kInheritanceTextStyle,
                shape: GFButtonShape.standard,
                color: colorbluegreyshade,
                size: 40,
                onPressed: (){
                  {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>  DeceasedLiabilities(amount: Total_Amount,)),
                  );
                  }
                }
            ),
          ]
      ),
    );
    showDialog(context: context,
        builder: (BuildContext context){
          return alertDialog;
        }
    );
  }



}

