import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'button.dart';
import 'constant.dart';
import 'primary_heirs.dart';
import 'deceased_data.dart';
import 'home.dart';
import 'unmarried_Heirs.dart';

class DeceasedLiabilities extends StatefulWidget {
   int amount;
   DeceasedLiabilities({Key? key, required this.amount}) : super(key: key);

  @override
  State<DeceasedLiabilities> createState() => _DeceasedLiabilitiesState();
}

class _DeceasedLiabilitiesState extends State<DeceasedLiabilities> {
  final _formKey = GlobalKey<FormState>();

  int? funeralExpenses = 0;
  int? debt = 0;
  int? haqMehar = 0;
  int? will = 0;

  void calculate() {
    setState(() {
      PropertyDetails.TotalAmount = widget.amount -
          (funeralExpenses! + debt! + haqMehar! + (will! * 1 / 3)).toInt();
      if (PropertyDetails.TotalAmount > 0) {
        deceasedWealth(context);
      } else {
        zeroWealth(context);
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Change your color here
          size: 30,
        ),
        title: const Padding(
          padding: EdgeInsets.only(left: 60.0),
          child: Text(
            'WarisApp',
            style: kAppBarTextStyle,
          ),
        ),
        elevation: 0.0,
      ),
      backgroundColor: colormustard,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: kBackgroundDecoration,
        child: Padding(
          padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                Text(
                  "Amount need to be deducted before distribution",
                  style: kHeadingTextStyle.copyWith(height: 1.4),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 20,
                ),
                TextFormField(
                  onChanged: (value) {
                    setState(() {
                      funeralExpenses = int.parse(value);
                    });
                  },
                  decoration: kInputDecoration.copyWith(
                      hintText: "Enter deceased funeral expenses"),
                  keyboardType: TextInputType.number,
                  maxLength: 20,
                  validator: ((value) {
                    if (value!.isEmpty) {
                      return 'Enter deceased funeral expenses';
                    } else if (!RegExp(r'^[0-9]').hasMatch(value)) {
                      return 'Enter numbers only';
                    }
                  }),
                ),
                const SizedBox(
                  height: 20,
                ),
                TextFormField(
                  onChanged: (value) {
                    setState(() {
                      debt = int.parse(value);
                    });
                  },
                  decoration:
                  kInputDecoration.copyWith(hintText: 'Enter Debt on deceased'),
                  keyboardType: TextInputType.number,
                  cursorColor: colorbluegrey,
                  maxLength: 25,
                  validator: ((value) {
                    if (value!.isEmpty) {
                      return "Enter Debt on deceased";
                    } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                      return 'Enter numbers only';
                    }
                  }),
                ),
                const SizedBox(
                  height: 20,
                ),
                Visibility(
                  visible: DeceasedDetails.showMaritalStatus &&
                      DeceasedDetails.gender == 'Male',
                  child: Column(
                    children: [
                      TextFormField(
                        onChanged: (value) {
                          setState(() {
                            haqMehar = int.parse(value);
                          });
                        },
                        decoration: kInputDecoration.copyWith(hintText: "Enter Haq Mehar"),
                        keyboardType: TextInputType.number,
                        maxLength: 25,
                        cursorColor: colorbluegrey,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Enter Haq Mehar price ";
                          } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                            return 'Enter numbers only';
                          }
                        },
                      ),
                      const SizedBox(
                        height: 22,
                      ),
                    ],
                  ),
                ),
                TextFormField(
                  onChanged: (value) {
                    setState(() {
                      will = int.parse(value);
                    });
                  },
                  decoration: kInputDecoration.copyWith(hintText: "Deceased's will"),
                  keyboardType: TextInputType.number,
                  cursorColor: colorbluegrey,
                  maxLength: 25,
                  validator: ((value) {
                    if (value!.isEmpty) {
                      return "Enter deceased's will price ";
                    } else if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                      return 'Enter numbers only';
                    }
                  }),
                ),
                const SizedBox(
                  height: 22,
                ),
                gfButton(
                  ButtonTitle: 'Next',
                  onPressed: () {
                    setState(() {
                      bool isValid = _formKey.currentState!.validate();
                    if (isValid) {
                      // Form is valid
                        calculate();
                    }
                    });
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Function to show an alert dialog for wealth distribution
void deceasedWealth(BuildContext context) {
  var alertDialog = AlertDialog(
    backgroundColor: colormustard,
    title: Text(
      'Wealth to be distributed Rs. ${PropertyDetails.TotalAmount}',
      textAlign: TextAlign.center,
      style: kInheritanceTextStyle,
    ),
    content: GFButton(
      icon: const Icon(
        Icons.check_circle,
        size: 20,
      ),
      text: "OK",
      textStyle: kInheritanceTextStyle,
      shape: GFButtonShape.standard,
      color: colorbluegreyshade,
      size: 40,
      onPressed: () {
        if (DeceasedDetails.maritalStatus == 'Married') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PrimaryHeirs()),
          );
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const UnmarriedHeirs()),
          );
        }
      },
    ),
  );
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alertDialog;
    },
  );
}

// Function to show an alert dialog when wealth is not sufficient for distribution
void zeroWealth(BuildContext context) {
  var alertDialog = AlertDialog(
    backgroundColor: colormustard,
    title: const Text(
      "Deceased's liabilities are more than the total wealth owned. Therefore, there is nothing to be distributed among heirs.",
      textAlign: TextAlign.center,
      style: kInheritanceTextStyle,
    ),
    content: GFButton(
      icon: const Icon(
        Icons.check_circle,
        size: 20,
      ),
      text: "OK",
      textStyle: kInheritanceTextStyle,
      shape: GFButtonShape.standard,
      color: colorbluegreyshade,
      size: 40,
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const Home()),
        );
      },
    ),
  );
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alertDialog;
    },
  );
}
