import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'authentication_repository.dart';
import 'constant.dart';
import 'package:get/get.dart';

import 'home.dart';

class ComplaintStatus extends StatefulWidget {

  ComplaintStatus({ super.key});

  @override
  State<ComplaintStatus> createState() => _ComplaintStatusState();
}

class _ComplaintStatusState extends State<ComplaintStatus> {

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: GFAppBar(
        backgroundColor: Colors.orange.shade300,
        iconTheme: const IconThemeData(
          color: colorblack,
          size: 30,
        ),
        title: Center(
          child: Text(
            "Complaint Status", // AppBar title
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
      ),
      body:  StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection("Complaints")
              .where("userEmail", isEqualTo: AuthenticationRepository.instance.userEmail)
              .snapshots(), // Filter by userEmail
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final docs = snapshot.data!.docs;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  // Title: "Pending Complaints"
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(
                      child: Text(
                        "Your Complaints",
                        style: kHeadingTextStyle,
                      ),
                    ),
                  ),

                  Expanded(
                    child: ListView.builder(
                      itemCount: docs.length,
                      itemBuilder: (context, i) {
                        final data = docs[i].data();

                        // Extracting complaint data
                        final complainerID = data['userEmail'] ?? 'N/A';
                        final complainerName = data['ComplainerName'] ?? 'N/A';
                        final complainerPhoneNo = data['ComplainerPhoneNo'] ?? 'N/A';
                        final complaintCity = data['ComplaintCity'] ?? 'N/A';
                        final complainerRelation = data['ComplainerRelation'] ?? 'N/A';
                        final deceasedName = data['DeceasedName'] ?? 'N/A';
                        final deceasedCNIC = data['DeceasedCNIC'] ?? 'N/A';
                        final description = data['Description'] ?? 'N/A';


                        return Container(
                          width: 250,
                          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          color: colormustard,
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                // Displaying complaint details
                                Text("Complainer ID: $complainerID"),
                                const SizedBox(height: 10),
                                Text("Complainer Name: $complainerName"),
                                const SizedBox(height: 10),
                                Text("Complainer Phone No: $complainerPhoneNo"),
                                const SizedBox(height: 10),
                                Text("Complaint City: $complaintCity"),
                                const SizedBox(height: 10),
                                Text("Deceased Name: $deceasedName"),
                                const SizedBox(height: 10),
                                Text("Deceased CNIC: $deceasedCNIC"),
                                const SizedBox(height: 10),
                                Text("Complainer Relation with deceased: $complainerRelation"),
                                const SizedBox(height: 10),
                                Text("Description: $description"),
                                const  SizedBox(height: 10),
                                const Divider(),
                                const Text("Complaint Status: Pending"),
                                const  SizedBox(height: 10),

                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              );
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          },
        ),
    );
  }
}
