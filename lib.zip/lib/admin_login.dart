import 'package:flutter/material.dart';
import 'package:get/get.dart'; // Importing GetX library
import 'package:practice/home.dart';
import 'package:practice/signup_controller.dart';
import 'constant.dart';
import 'button.dart'; // Importing the RoundedButton class

class AdminLogin extends StatefulWidget {
  const AdminLogin({Key? key}) : super(key: key);

  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
  final _formKey = GlobalKey<FormState>(); // Form key for validation
  final controller =
      Get.put(SignUpController()); // Initializing GetX controller
  String countryCode ="+92"; // Controller for country code

  @override
  void initState() {
    super.initState();
  }

  void _validation() async {
     bool isValid = _formKey.currentState!.validate();
    if (isValid) {
      // Form is valid
      bool? temp = SignUpController.instance.loginAdmin(
        controller.adminEmail.text.trim(),
        (countryCode+controller.adminphoneNo.text.trim()),
        controller.adminPassword.text.trim(),
      );
      if (temp == true) {
        _formKey.currentState!.reset(); // Resetting the form
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.black, // Changing icon color
          size: 30,
        ),
        title: Center(
          child: Text(
            'Admin Login', // AppBar title
            style: kAppBarTextStyle.copyWith(fontStyle: FontStyle.italic),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        const Home()), // Navigating to Home page
              );
            },
            icon: const Icon(
              Icons.home, // Home icon
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: 800,
          decoration: kBackgroundDecoration, // Applying background decoration
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0, top: 70.0, right: 10.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  SizedBox(
                    height: 200.0,
                    child: Image.asset(
                        'images/logo_BgRemove.png'), // Displaying an image
                  ),
                  const SizedBox(
                    height: 30.0,
                  ),
                  TextFormField(
                    controller: controller.adminEmail,
                    decoration: kTextFieldDecoration.copyWith(
                        hintText: "Enter your email"), // Email text field
                    cursorColor: colorbluegrey,
                    validator: (value) {
                      if (value!.isEmpty)
                        {return 'Please enter your email';}
                      else if (!RegExp(r'^[a-z A-Z 0-9]+@gmail+.com+$')
                          .hasMatch(value)) {
                        return 'Email must contain "@gmail.com"';
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10.0,
                  ),
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                      border: Border.all(color: colorbluegrey, width: 2.0),
                      borderRadius: BorderRadius.all(Radius.circular(50.0)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(
                            width: 40,
                            child: Text(
                              "+92",
                            ),
                          ),
                          const Text(
                            "|",
                            style: TextStyle(fontSize: 33, color: Colors.grey),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: TextFormField(
                              keyboardType: TextInputType.phone,
                              controller: controller.adminphoneNo,
                              decoration: const InputDecoration(
                                counterText: '',
                                border: InputBorder.none,
                                hintText: "Phone Number(3...)",
                                hintStyle: TextStyle(color: Colors.black),
                              ),
                              maxLength: 10,
                              cursorColor: colorbluegrey,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter your phone number';
                                }else if (!RegExp(r'^3+[0-4]+[0-9]')
                                    .hasMatch(value)) {
                                  return 'Invalid Phone number"';
                                }
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10.0,
                  ),
                  TextFormField(
                    controller: controller.adminPassword,
                    decoration: kTextFieldDecoration.copyWith(
                        hintText: "Enter your password"),
                    cursorColor: colorbluegrey,
                    obscureText: true,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please enter password ";
                      }
                    },
                  ),
                  const SizedBox(
                    height: 5.0,
                  ),
                  RoundedButton(
                    title: 'Log In', // Rounded button for login
                    onPressed: () {
                      _validation(); // Calling validation function
                    },
                  ),
                  const SizedBox(
                    height: 5.0,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
